import { FormEvent, useEffect, useState } from 'react';
import { AppShell } from '../components/AppShell';
import { createSubmission, getPatterns, PatternSummary, SubmissionPayload, subscribeDigest } from '../lib/api';

export function SubmitPage() {
  const [patterns, setPatterns] = useState<PatternSummary[]>([]);
  const [form, setForm] = useState<SubmissionPayload>({
    productName: '',
    websiteUrl: '',
    contactEmail: '',
    selectedPattern: '',
    screenshotUrl: '',
    notes: '',
  });
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    getPatterns()
      .then((result) => setPatterns(result.items))
      .catch(() => setPatterns([]));
  }, []);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setMessage(null);
    try {
      await createSubmission(form);
      setForm({
        productName: '',
        websiteUrl: '',
        contactEmail: '',
        selectedPattern: '',
        screenshotUrl: '',
        notes: '',
      });
      setMessage('提交成功，已进入审核队列。');
    } catch (err) {
      setError((err as Error).message);
    }
  }

  async function handleSubscribe(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setMessage(null);
    try {
      await subscribeDigest(email);
      setMessage('已订阅每周 Digest。');
      setEmail('');
    } catch (err) {
      setError((err as Error).message);
    }
  }

  return (
    <AppShell title="提交产品" subtitle="把新产品送进审核流程，同时把访客转成 Digest 订阅用户，形成早期增长闭环。">
      <section className="two-column">
        <form className="panel form-panel" onSubmit={handleSubmit}>
          <h2>提交一个产品</h2>
          <label className="field">
            <span>产品名称</span>
            <input value={form.productName} onChange={(event) => setForm({ ...form, productName: event.target.value })} required />
          </label>
          <label className="field">
            <span>官网地址</span>
            <input value={form.websiteUrl} onChange={(event) => setForm({ ...form, websiteUrl: event.target.value })} required />
          </label>
          <label className="field">
            <span>联系邮箱</span>
            <input value={form.contactEmail} onChange={(event) => setForm({ ...form, contactEmail: event.target.value })} required />
          </label>
          <label className="field">
            <span>关联模式</span>
            <select value={form.selectedPattern} onChange={(event) => setForm({ ...form, selectedPattern: event.target.value })}>
              <option value="">稍后再选</option>
              {patterns.map((pattern) => (
                <option key={pattern.id} value={pattern.slug}>
                  {pattern.name}
                </option>
              ))}
            </select>
          </label>
          <label className="field">
            <span>截图链接</span>
            <input value={form.screenshotUrl} onChange={(event) => setForm({ ...form, screenshotUrl: event.target.value })} />
          </label>
          <label className="field">
            <span>补充说明</span>
            <textarea value={form.notes} onChange={(event) => setForm({ ...form, notes: event.target.value })} rows={5} />
          </label>
          <button className="primary-button" type="submit">
            提交审核
          </button>
        </form>

        <form className="panel form-panel" onSubmit={handleSubscribe}>
          <h2>免费 Digest</h2>
          <p className="subtitle compact-copy">每周精选新产品、模式变化和运营观察，适合持续跟踪赛道动向。</p>
          <label className="field">
            <span>邮箱</span>
            <input value={email} onChange={(event) => setEmail(event.target.value)} required />
          </label>
          <button className="primary-button" type="submit">
            立即订阅
          </button>
          {message ? <p className="success-text">{message}</p> : null}
          {error ? <p className="error-text">{error}</p> : null}
        </form>
      </section>
    </AppShell>
  );
}
