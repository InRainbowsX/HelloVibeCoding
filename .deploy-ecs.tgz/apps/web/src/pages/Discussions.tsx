import { FormEvent, useEffect, useMemo, useState } from 'react';
import { AppShell } from '../components/AppShell';
import { createComment, DiscussionItem, getDiscussion, getDiscussions } from '../lib/api';

const targetTypeMap: Record<'APP' | 'PATTERN', string> = {
  APP: '应用',
  PATTERN: '模式',
};

export function DiscussionsPage() {
  const [items, setItems] = useState<DiscussionItem[]>([]);
  const [selectedId, setSelectedId] = useState<string>('');
  const [selected, setSelected] = useState<DiscussionItem | null>(null);
  const [authorName, setAuthorName] = useState('');
  const [content, setContent] = useState('');
  const [replyToCommentId, setReplyToCommentId] = useState('');
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    getDiscussions({ sort: 'latest', page: 1, pageSize: 12 })
      .then((result) => {
        if (!active) return;
        setItems(result.items);
        setSelectedId((current) => current || result.items[0]?.id || '');
        setError(null);
      })
      .catch((err: Error) => {
        if (!active) return;
        setError(err.message);
      });

    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (!selectedId) return;
    let active = true;
    getDiscussion(selectedId)
      .then((result) => {
        if (!active) return;
        setSelected(result);
      })
      .catch((err: Error) => {
        if (!active) return;
        setError(err.message);
      });

    return () => {
      active = false;
    };
  }, [selectedId]);

  const replyOptions = useMemo(() => selected?.comments || [], [selected]);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selectedId) return;
    setMessage(null);
    setError(null);
    try {
      await createComment(selectedId, {
        authorName,
        content,
        replyToCommentId: replyToCommentId || undefined,
      });
      const refreshed = await getDiscussion(selectedId);
      setSelected(refreshed);
      setItems((current) => current.map((item) => (item.id === selectedId ? refreshed : item)));
      setAuthorName('');
      setContent('');
      setReplyToCommentId('');
      setMessage('评论已发布。');
    } catch (err) {
      setError((err as Error).message);
    }
  }

  return (
    <AppShell
      title="讨论区"
      subtitle="使用扁平评论流，不做树状层级；回复只通过引用条标记，保证阅读速度和信息密度。"
    >
      {error ? <section className="panel error-state">{error}</section> : null}
      <section className="two-column discussion-layout">
        <div className="stream-list">
          {items.map((discussion) => (
            <button
              key={discussion.id}
              type="button"
              className={`panel discussion-card discussion-select${selectedId === discussion.id ? ' is-selected' : ''}`}
              onClick={() => setSelectedId(discussion.id)}
            >
              <div className="discussion-head">
                <div>
                  <p className="eyebrow">{targetTypeMap[discussion.targetType]}</p>
                  <h2>{discussion.title}</h2>
                </div>
                <strong>{discussion.likesCount} 赞</strong>
              </div>
              <p className="compact-copy">{discussion.comments.length} 条评论</p>
            </button>
          ))}
          {items.length === 0 && !error ? <section className="panel empty-state">还没有讨论内容。</section> : null}
        </div>

        <div className="stream-list">
          <section className="panel discussion-card">
            {!selected ? (
              <p className="empty-inline">请选择左侧讨论。</p>
            ) : (
              <>
                <div className="discussion-head">
                  <div>
                    <p className="eyebrow">{targetTypeMap[selected.targetType]}</p>
                    <h2>{selected.title}</h2>
                  </div>
                  <strong>{selected.likesCount} 赞</strong>
                </div>
                <div className="comment-stream">
                  {selected.comments.map((comment) => (
                    <div key={comment.id} className="comment-line">
                      {comment.replyToCommentId ? (
                        <span className="quote-tag">回复 {comment.replyToCommentId.slice(0, 6)}</span>
                      ) : null}
                      <strong>{comment.authorName}</strong>
                      <p>{comment.content}</p>
                    </div>
                  ))}
                  {selected.comments.length === 0 ? <p className="empty-inline">还没有评论。</p> : null}
                </div>
              </>
            )}
          </section>

          <form className="panel form-panel" onSubmit={handleSubmit}>
            <h2>发表评论</h2>
            <label className="field">
              <span>昵称</span>
              <input value={authorName} onChange={(event) => setAuthorName(event.target.value)} required />
            </label>
            <label className="field">
              <span>回复对象</span>
              <select value={replyToCommentId} onChange={(event) => setReplyToCommentId(event.target.value)}>
                <option value="">作为新评论发布</option>
                {replyOptions.map((comment) => (
                  <option key={comment.id} value={comment.id}>
                    {comment.authorName}：{comment.content.slice(0, 24)}
                  </option>
                ))}
              </select>
            </label>
            <label className="field">
              <span>内容</span>
              <textarea value={content} onChange={(event) => setContent(event.target.value)} rows={5} required />
            </label>
            <button className="primary-button" type="submit" disabled={!selectedId}>
              发布评论
            </button>
            {message ? <p className="success-text">{message}</p> : null}
          </form>
        </div>
      </section>
    </AppShell>
  );
}
