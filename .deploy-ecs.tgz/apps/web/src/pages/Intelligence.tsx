import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { AppShell } from '../components/AppShell';
import { AppDetail, getAppDetail } from '../lib/api';

const breakdownOrder = [
  'painAndPersona',
  'triggerScene',
  'corePromise',
  'ahaMoment',
  'retentionLoop',
  'growthEngine',
  'monetization',
  'moat',
] as const;

const breakdownLabelMap: Record<(typeof breakdownOrder)[number], string> = {
  painAndPersona: '痛点与人群',
  triggerScene: '触发场景',
  corePromise: '核心承诺',
  ahaMoment: '首次惊喜时刻',
  retentionLoop: '留存循环',
  growthEngine: '增长引擎',
  monetization: '变现方式',
  moat: '护城河',
};

export function IntelligencePage() {
  const { slug = 'podclip-studio' } = useParams();
  const [data, setData] = useState<AppDetail | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    getAppDetail(slug)
      .then((result) => {
        if (!active) return;
        setData(result);
        setError(null);
      })
      .catch((err: Error) => {
        if (!active) return;
        setError(err.message);
      });

    return () => {
      active = false;
    };
  }, [slug]);

  return (
    <AppShell
      title={data?.name || '产品拆解'}
      subtitle="先给结论，再给证据：首屏三张结论卡，随后进入 8 格拆解、同模式家族与讨论区。"
    >
      {error ? <section className="panel error-state">{error}</section> : null}
      {!data ? <section className="panel empty-state">正在加载产品拆解...</section> : null}
      {data ? (
        <>
          <section className="metric-grid">
            <article className="panel metric-card">
              <span className="muted-label">核心承诺</span>
              <strong>{data.breakdown.corePromise || '待补充'}</strong>
            </article>
            <article className="panel metric-card">
              <span className="muted-label">增长引擎</span>
              <strong>{data.breakdown.growthEngine || '待补充'}</strong>
            </article>
            <article className="panel metric-card">
              <span className="muted-label">变现方式</span>
              <strong>{data.breakdown.monetization || '待补充'}</strong>
            </article>
          </section>

          <section className="panel breakdown-grid">
            {breakdownOrder.map((key) => (
              <article key={key} className="breakdown-card">
                <span className="muted-label">{breakdownLabelMap[key]}</span>
                <p>{data.breakdown[key] || '待补充'}</p>
              </article>
            ))}
          </section>

          <section className="two-column">
            <div className="panel">
              <h2>同模式家族</h2>
              <p>{data.pattern?.description || '当前还没有关联模式。'}</p>
              <div className="stack-list">
                {data.pattern?.relatedApps?.map((item) => (
                  <Link key={item.slug} to={`/intelligence/${item.slug}`} className="list-item-link">
                    <span>{item.name}</span>
                    <strong>{item.heatScore}</strong>
                  </Link>
                )) || <p className="empty-inline">暂无同模式产品。</p>}
              </div>
            </div>
            <div className="panel">
              <h2>相关讨论</h2>
              <div className="stack-list">
                {data.discussions.map((discussion) => (
                  <div key={discussion.id} className="list-item-static">
                    <strong>{discussion.title}</strong>
                    <span>{discussion.comments.length} 条评论</span>
                  </div>
                ))}
                {data.discussions.length === 0 ? <p className="empty-inline">暂无讨论。</p> : null}
              </div>
            </div>
          </section>
        </>
      ) : null}
    </AppShell>
  );
}
