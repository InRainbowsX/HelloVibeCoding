import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { AppShell } from '../components/AppShell';
import { AppSummary, getApps, getPatterns, PatternSummary } from '../lib/api';

const pricingOptions = ['ALL', 'FREE', 'FREEMIUM', 'PAID', 'USAGE_BASED'];
const pricingLabelMap: Record<string, string> = {
  ALL: '全部',
  FREE: '免费',
  FREEMIUM: '免费增值',
  PAID: '付费',
  USAGE_BASED: '按量付费',
};

export function DirectoryPage() {
  const [items, setItems] = useState<AppSummary[]>([]);
  const [patterns, setPatterns] = useState<PatternSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState('hot');
  const [pricing, setPricing] = useState('ALL');
  const [pattern, setPattern] = useState('');
  const [page, setPage] = useState(1);
  const [pageSize] = useState(6);
  const [total, setTotal] = useState(0);
  const [expanded, setExpanded] = useState<string | null>(null);

  useEffect(() => {
    getPatterns()
      .then((result) => setPatterns(result.items))
      .catch(() => setPatterns([]));
  }, []);

  useEffect(() => {
    let active = true;
    setLoading(true);
    getApps({
      search,
      sort,
      pattern,
      pricing: pricing === 'ALL' ? undefined : pricing,
      page,
      pageSize,
    })
      .then((result) => {
        if (!active) return;
        setItems(result.items);
        setTotal(result.total);
        setError(null);
      })
      .catch((err: Error) => {
        if (!active) return;
        setError(err.message);
      })
      .finally(() => {
        if (!active) return;
        setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [page, pageSize, pattern, pricing, search, sort]);

  useEffect(() => {
    setPage(1);
  }, [search, sort, pricing, pattern]);

  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  const stats = useMemo(
    () => [
      { label: '当前页产品', value: String(items.length) },
      { label: '匹配总数', value: String(total) },
      { label: '分页', value: `${page}/${totalPages}` },
    ],
    [items.length, page, total, totalPages],
  );

  return (
    <AppShell
      title="产品库"
      subtitle="默认 6 列信息视图，配合行展开查看目标人群、冷启动亮点和讨论热度，保持信息密度但不拥挤。"
      actions={
        <div className="stat-row">
          {stats.map((stat) => (
            <div key={stat.label} className="stat-card">
              <span>{stat.label}</span>
              <strong>{stat.value}</strong>
            </div>
          ))}
        </div>
      }
    >
      <section className="panel filter-bar filter-grid-4">
        <label className="field">
          <span>搜索</span>
          <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="搜索产品名或一句话描述" />
        </label>
        <label className="field compact-field">
          <span>模式</span>
          <select value={pattern} onChange={(event) => setPattern(event.target.value)}>
            <option value="">全部模式</option>
            {patterns.map((item) => (
              <option key={item.id} value={item.slug}>
                {item.name}
              </option>
            ))}
          </select>
        </label>
        <label className="field compact-field">
          <span>定价</span>
          <select value={pricing} onChange={(event) => setPricing(event.target.value)}>
            {pricingOptions.map((option) => (
              <option key={option} value={option}>
                {pricingLabelMap[option]}
              </option>
            ))}
          </select>
        </label>
        <label className="field compact-field">
          <span>排序</span>
          <select value={sort} onChange={(event) => setSort(event.target.value)}>
            <option value="hot">热度优先</option>
            <option value="latest">最新收录</option>
            <option value="difficulty">难度从低到高</option>
          </select>
        </label>
      </section>

      <section className="panel table-panel">
        <div className="table-head directory-grid">
          <span>产品</span>
          <span>定价</span>
          <span>模式</span>
          <span>渠道</span>
          <span>热度</span>
          <span>难度</span>
        </div>
        {loading ? <div className="empty-state">正在加载产品...</div> : null}
        {error ? <div className="empty-state error-state">{error}</div> : null}
        {!loading && !error && items.length === 0 ? <div className="empty-state">没有找到匹配产品。</div> : null}
        {!loading && !error
          ? items.map((item) => (
              <div key={item.id} className="row-wrap">
                <button
                  type="button"
                  className="table-row directory-grid"
                  onClick={() => setExpanded(expanded === item.id ? null : item.id)}
                >
                  <span>
                    <strong>{item.name}</strong>
                    <small>{item.tagline || '暂无一句话描述'}</small>
                  </span>
                  <span>{pricingLabelMap[item.pricing] || item.pricing}</span>
                  <span>{item.pattern?.name || '未归类'}</span>
                  <span>{item.channels.join(' / ')}</span>
                  <span>{item.heatScore}</span>
                  <span>{item.difficulty}/5</span>
                </button>
                {expanded === item.id ? (
                  <div className="row-expand">
                    <div>
                      <span className="muted-label">目标人群</span>
                      <p>{item.targetPersona || '待补充'}</p>
                    </div>
                    <div>
                      <span className="muted-label">冷启动亮点</span>
                      <p>{item.coldStartHighlight || '待补充'}</p>
                    </div>
                    <div>
                      <span className="muted-label">讨论热度</span>
                      <p>{item.discussionCount} 条讨论</p>
                    </div>
                    <Link className="inline-link" to={`/intelligence/${item.slug}`}>
                      查看拆解详情
                    </Link>
                  </div>
                ) : null}
              </div>
            ))
          : null}
      </section>

      <section className="pagination-row">
        <button className="secondary-button" type="button" onClick={() => setPage((current) => Math.max(1, current - 1))} disabled={page <= 1}>
          上一页
        </button>
        <span className="page-pill">
          第 {page} / {totalPages} 页
        </span>
        <button
          className="secondary-button"
          type="button"
          onClick={() => setPage((current) => Math.min(totalPages, current + 1))}
          disabled={page >= totalPages}
        >
          下一页
        </button>
      </section>
    </AppShell>
  );
}
