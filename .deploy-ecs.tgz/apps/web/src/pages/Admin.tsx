import { FormEvent, useEffect, useState } from 'react';
import { AppShell } from '../components/AppShell';
import { getAdminSubmissions, reviewSubmission, SubmissionRecord } from '../lib/api';

const statusLabelMap: Record<'PENDING' | 'APPROVED' | 'REJECTED', string> = {
  PENDING: '待审核',
  APPROVED: '已通过',
  REJECTED: '已拒绝',
};

export function AdminPage() {
  const [items, setItems] = useState<SubmissionRecord[]>([]);
  const [status, setStatus] = useState<'PENDING' | 'APPROVED' | 'REJECTED'>('PENDING');
  const [slugDrafts, setSlugDrafts] = useState<Record<string, string>>({});
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  function load(targetStatus: string) {
    getAdminSubmissions(targetStatus)
      .then((result) => {
        setItems(result);
        setError(null);
      })
      .catch((err: Error) => {
        setError(err.message);
      });
  }

  useEffect(() => {
    load(status);
  }, [status]);

  async function runReview(item: SubmissionRecord, nextStatus: 'APPROVED' | 'REJECTED') {
    setMessage(null);
    setError(null);
    try {
      await reviewSubmission(item.id, {
        status: nextStatus,
        slug: slugDrafts[item.id],
      });
      setMessage(`${item.productName} 已标记为${statusLabelMap[nextStatus]}。`);
      load(status);
    } catch (err) {
      setError((err as Error).message);
    }
  }

  async function handleApprove(event: FormEvent<HTMLFormElement>, item: SubmissionRecord) {
    event.preventDefault();
    await runReview(item, 'APPROVED');
  }

  return (
    <AppShell title="审核台" subtitle="集中查看用户提交，审核通过后自动生成草稿产品，保持产品库持续更新。">
      <section className="panel filter-bar">
        <label className="field compact-field">
          <span>审核状态</span>
          <select value={status} onChange={(event) => setStatus(event.target.value as 'PENDING' | 'APPROVED' | 'REJECTED')}>
            <option value="PENDING">待审核</option>
            <option value="APPROVED">已通过</option>
            <option value="REJECTED">已拒绝</option>
          </select>
        </label>
      </section>
      {message ? <section className="panel success-text">{message}</section> : null}
      {error ? <section className="panel error-text">{error}</section> : null}
      <section className="stream-list">
        {items.map((item) => (
          <article key={item.id} className="panel review-card">
            <div className="discussion-head">
              <div>
                <p className="eyebrow">{statusLabelMap[item.status]}</p>
                <h2>{item.productName}</h2>
                <p className="compact-copy">{item.websiteUrl}</p>
              </div>
              <strong>{item.contactEmail}</strong>
            </div>
            <form className="review-form" onSubmit={(event) => void handleApprove(event, item)}>
              <label className="field">
                <span>发布 slug</span>
                <input
                  value={slugDrafts[item.id] || ''}
                  onChange={(event) =>
                    setSlugDrafts((current) => ({
                      ...current,
                      [item.id]: event.target.value,
                    }))
                  }
                  placeholder="可选，自定义英文 slug"
                />
              </label>
              <div className="button-row">
                <button className="primary-button" type="submit">
                  通过并生成草稿
                </button>
                <button className="secondary-button" type="button" onClick={() => void runReview(item, 'REJECTED')}>
                  拒绝
                </button>
              </div>
            </form>
          </article>
        ))}
        {items.length === 0 ? <section className="panel empty-state">当前状态下没有提交记录。</section> : null}
      </section>
    </AppShell>
  );
}
