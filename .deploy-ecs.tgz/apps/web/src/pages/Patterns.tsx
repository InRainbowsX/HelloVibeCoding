import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { AppShell } from '../components/AppShell';
import { getPatternDetail, PatternDetail } from '../lib/api';

const pricingLabelMap: Record<string, string> = {
  FREE: '免费',
  FREEMIUM: '免费增值',
  PAID: '付费',
  USAGE_BASED: '按量付费',
};

export function PatternsPage() {
  const { slug = 'podcast-clipping' } = useParams();
  const [data, setData] = useState<PatternDetail | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    getPatternDetail(slug)
      .then((result) => {
        if (!active) return;
        setData(result);
        setError(null);
      })
      .catch((err: Error) => {
        if (!active) return;
        setError(err.message);
      });

    return () => {
      active = false;
    };
  }, [slug]);

  return (
    <AppShell title={data?.name || '模式详情'} subtitle="模式页聚合同类商业机制，帮助快速看到哪些已上线产品验证过这条路径。">
      {error ? <section className="panel error-state">{error}</section> : null}
      {!data ? <section className="panel empty-state">正在加载模式详情...</section> : null}
      {data ? (
        <section className="two-column">
          <div className="panel">
            <h2>模式说明</h2>
            <p>{data.description}</p>
            <div className="tag-row">
              {data.useCases.map((tag) => (
                <span key={tag} className="tag-chip">
                  {tag}
                </span>
              ))}
            </div>
          </div>
          <div className="panel">
            <h2>相关产品</h2>
            <div className="stack-list">
              {data.apps.map((app) => (
                <Link key={app.slug} to={`/intelligence/${app.slug}`} className="list-item-link">
                  <span>{app.name} · {pricingLabelMap[app.pricing] || app.pricing}</span>
                  <strong>{app.heatScore}</strong>
                </Link>
              ))}
            </div>
          </div>
        </section>
      ) : null}
    </AppShell>
  );
}
