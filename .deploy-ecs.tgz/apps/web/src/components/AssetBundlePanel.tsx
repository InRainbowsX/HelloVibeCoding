import { Download, Layers } from 'lucide-react';
import { cn } from '../utils';

export type AssetPreviewKey = 'agents' | 'spec' | 'prompt';

export interface AssetEntry {
  key: AssetPreviewKey;
  label: string;
  available: boolean;
  content: string;
  desc: string;
}

interface AssetBundlePanelProps {
  appSlug: string;
  assetEntries: AssetEntry[];
  activeAssetKey: AssetPreviewKey;
  copiedAssetKey: AssetPreviewKey | null;
  onSelect: (key: AssetPreviewKey) => void;
  onCopy: () => void;
}

function downloadAsset(appSlug: string, asset: AssetEntry) {
  if (!asset.available || !asset.content) return;
  const extension = asset.key === 'prompt' ? 'txt' : 'md';
  const blob = new Blob([asset.content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `${appSlug}-${asset.key}.${extension}`;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}

function downloadAllAssets(appSlug: string, assetEntries: AssetEntry[]) {
  assetEntries.filter((asset) => asset.available && asset.content).forEach((asset, index) => {
    window.setTimeout(() => downloadAsset(appSlug, asset), index * 120);
  });
}

export function AssetBundlePanel({
  appSlug,
  assetEntries,
  activeAssetKey,
  copiedAssetKey,
  onSelect,
  onCopy,
}: AssetBundlePanelProps) {
  const activeAsset = assetEntries.find((asset) => asset.key === activeAssetKey) || assetEntries[0];

  return (
    <section className="bg-white border border-brand-line/5 rounded-3xl p-8 space-y-6 shadow-sm">
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-serif italic flex items-center gap-3">
            <Layers className="h-5 w-5 text-brand-ink/45" />
            可建造资产
          </h2>
          <p className="mt-2 text-sm text-brand-ink/50">把拆解直接转成工程蓝图，便于复制到实际开发流程。</p>
        </div>
        <div className="flex gap-3">
          <button
            type="button"
            onClick={onCopy}
            disabled={!activeAsset?.available || !activeAsset.content}
            className="inline-flex items-center justify-center rounded-2xl border border-brand-line/10 bg-white px-4 py-2 text-xs font-bold text-brand-ink/65 transition-colors hover:bg-brand-ink/5 disabled:cursor-not-allowed disabled:opacity-40"
          >
            {copiedAssetKey === activeAsset?.key ? '已复制' : '复制当前内容'}
          </button>
          <button
            type="button"
            onClick={() => downloadAsset(appSlug, activeAsset)}
            disabled={!activeAsset?.available || !activeAsset.content}
            className="inline-flex items-center justify-center gap-2 rounded-2xl border border-brand-line/10 bg-white px-4 py-2 text-xs font-bold text-brand-ink/65 transition-colors hover:bg-brand-ink/5 disabled:cursor-not-allowed disabled:opacity-40"
          >
            <Download className="h-3.5 w-3.5" />
            下载当前文件
          </button>
          <button
            type="button"
            onClick={() => downloadAllAssets(appSlug, assetEntries)}
            disabled={!assetEntries.some((asset) => asset.available && asset.content)}
            className="inline-flex items-center justify-center gap-2 rounded-2xl border border-brand-line/10 bg-white px-4 py-2 text-xs font-bold text-brand-ink/65 transition-colors hover:bg-brand-ink/5 disabled:cursor-not-allowed disabled:opacity-40"
          >
            <Download className="h-3.5 w-3.5" />
            下载全部
          </button>
        </div>
      </div>
      <div className="flex flex-wrap gap-2">
        {assetEntries.map((asset) => (
          <button
            key={asset.key}
            type="button"
            onClick={() => onSelect(asset.key)}
            className={cn(
              'rounded-full border px-4 py-2 text-sm font-medium transition-colors',
              activeAssetKey === asset.key
                ? 'border-brand-ink bg-brand-ink text-brand-bg'
                : 'border-brand-line/10 bg-white text-brand-ink/60 hover:border-brand-ink/30',
            )}
          >
            {asset.label}
          </button>
        ))}
      </div>
      <div className="rounded-3xl border border-brand-line/10 bg-brand-ink/[0.02] p-5">
        <div className="flex items-center justify-between gap-4">
          <div>
            <div className="text-sm font-semibold text-brand-ink">{activeAsset.label}</div>
            <div className="mt-1 text-xs text-brand-ink/45">{activeAsset.desc}</div>
          </div>
          <span className={cn('text-[10px] font-mono uppercase tracking-[0.22em]', activeAsset.available ? 'text-emerald-600' : 'text-brand-ink/25')}>
            {activeAsset.available ? 'Ready' : 'Empty'}
          </span>
        </div>
        <pre className="mt-4 overflow-x-auto whitespace-pre-wrap rounded-2xl border border-brand-line/10 bg-white p-4 text-xs leading-6 text-brand-ink/70">
          {activeAsset.available && activeAsset.content ? activeAsset.content : '当前资产尚未生成内容。'}
        </pre>
      </div>
    </section>
  );
}
