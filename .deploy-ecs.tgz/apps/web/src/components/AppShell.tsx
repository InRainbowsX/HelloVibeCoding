import type { ReactNode } from 'react';
import { Link, NavLink } from 'react-router-dom';

const links = [
  { to: '/directory', label: '产品库' },
  { to: '/discussions', label: '讨论区' },
  { to: '/patterns/podcast-clipping', label: '模式库' },
  { to: '/submit', label: '提交产品' },
  { to: '/admin', label: '审核台' },
];

export function AppShell(props: { title: string; subtitle: string; actions?: ReactNode; children: ReactNode }) {
  return (
    <div className="shell">
      <header className="topbar">
        <Link to="/directory" className="brand">
          helloVibeCoding
        </Link>
        <nav className="nav" aria-label="主导航">
          {links.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}
            >
              {link.label}
            </NavLink>
          ))}
        </nav>
      </header>
      <main className="page-frame">
        <section className="page-hero">
          <div>
            <p className="eyebrow">产品情报系统</p>
            <h1>{props.title}</h1>
            <p className="subtitle">{props.subtitle}</p>
          </div>
          {props.actions ? <div className="hero-actions">{props.actions}</div> : null}
        </section>
        {props.children}
      </main>
    </div>
  );
}
