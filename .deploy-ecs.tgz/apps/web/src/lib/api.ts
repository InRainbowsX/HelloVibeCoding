const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3001/api/v1';

export interface AppSummary {
  id: string;
  slug: string;
  name: string;
  tagline?: string | null;
  saveTimeLabel: string;
  category: string;
  pricing: string;
  channels: string[];
  targetPersona: string;
  hookAngle: string;
  trustSignals: string[];
  difficulty: number;
  heatScore: number;
  pattern: { slug: string; name: string } | null;
  coldStartHighlight?: string | null;
  discussionCount: number;
  createdAt: string;
}

export interface PaginatedResult<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
}

export interface AppDetail {
  id: string;
  slug: string;
  name: string;
  tagline?: string | null;
  saveTimeLabel: string;
  category: string;
  pricing: string;
  channels: string[];
  targetPersona: string;
  hookAngle: string;
  trustSignals: string[];
  difficulty: number;
  heatScore: number;
  screenshotUrls: string[];
  breakdown: Record<string, string | null>;
  pattern: {
    id: string;
    slug: string;
    name: string;
    description: string;
    relatedApps: Array<{ slug: string; name: string; heatScore: number }>;
  } | null;
  teardown: {
    painSummary: string;
    painScore: string;
    triggerScene: string;
    corePromise: string;
    coreLoop: string;
    keyConstraints: string[];
    mvpScope: string;
    dataInput?: string | null;
    dataOutput?: string | null;
    faultTolerance?: string | null;
    coldStartStrategy: string;
    pricingLogic: string;
    competitorDelta: string;
    riskNotes: string;
    expansionSteps: string[];
    reverseIdeas: string[];
  } | null;
  buildAssets: {
    hasAgentsTemplate: boolean;
    hasSpecTemplate: boolean;
    hasPromptPack: boolean;
    agentsTemplate?: string | null;
    specTemplate?: string | null;
    promptPack?: string | null;
  };
  discussions: Array<{
    id: string;
    title: string;
    likesCount: number;
    createdAt: string;
    comments: Array<{
      id: string;
      authorName: string;
      content: string;
      replyToCommentId?: string | null;
      likesCount: number;
      createdAt: string;
    }>;
  }>;
}

export interface DiscussionItem {
  id: string;
  title: string;
  targetType: 'APP' | 'PATTERN';
  targetId: string;
  likesCount: number;
  createdAt: string;
  comments: Array<{
    id: string;
    authorName: string;
    content: string;
    replyToCommentId?: string | null;
    likesCount: number;
    createdAt: string;
  }>;
}

export interface CreateDiscussionPayload {
  title: string;
  targetType: 'APP' | 'PATTERN';
  targetId: string;
  authorName: string;
  content: string;
}

export interface PatternDetail {
  id: string;
  slug: string;
  name: string;
  description: string;
  useCases: string[];
  apps: Array<{ slug: string; name: string; pricing: string; heatScore: number }>;
}

export interface PatternSummary {
  id: string;
  slug: string;
  name: string;
  description: string;
  useCases: string[];
  appCount: number;
}

export interface SubmissionPayload {
  productName: string;
  websiteUrl: string;
  contactEmail: string;
  screenshotUrl?: string;
  selectedPattern?: string;
  notes?: string;
}

export interface SubmissionRecord {
  id: string;
  productName: string;
  websiteUrl: string;
  contactEmail: string;
  screenshotUrl?: string | null;
  selectedPattern?: string | null;
  notes?: string | null;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  createdAt: string;
}

export interface ReviewSubmissionPayload {
  status: 'APPROVED' | 'REJECTED';
  slug?: string;
}

export interface AdminAppRecord {
  id: string;
  slug: string;
  name: string;
  tagline?: string | null;
  saveTimeLabel: string;
  category: string;
  pricing: string;
  channels: string[];
  targetPersona: string;
  hookAngle: string;
  trustSignals: string[];
  difficulty: number;
  heatScore: number;
  screenshotUrls: string[];
  patternId?: string | null;
  teardown?: {
    painSummary: string;
    painScore: string;
    triggerScene: string;
    corePromise: string;
    coreLoop: string;
    keyConstraints: string[];
    mvpScope: string;
    dataInput?: string | null;
    dataOutput?: string | null;
    faultTolerance?: string | null;
    coldStartStrategy: string;
    pricingLogic: string;
    competitorDelta: string;
    riskNotes: string;
    expansionSteps: string[];
    reverseIdeas: string[];
  } | null;
  assetBundle?: {
    hasAgentsTemplate: boolean;
    hasSpecTemplate: boolean;
    hasPromptPack: boolean;
    agentsTemplate?: string | null;
    specTemplate?: string | null;
    promptPack?: string | null;
  } | null;
}

export interface AdminPatternRecord {
  id: string;
  slug: string;
  name: string;
  description: string;
  useCases: string[];
  apps: Array<{ id: string; name: string; slug: string }>;
}

export interface AdminDiscussionRecord extends DiscussionItem {}

export interface SubscriberRecord {
  id: string;
  email: string;
  createdAt: string;
}

function withQuery(path: string, query?: Record<string, string | number | undefined>) {
  if (!query) return path;
  const search = new URLSearchParams();
  Object.entries(query).forEach(([key, value]) => {
    if (value !== undefined && value !== '') {
      search.set(key, String(value));
    }
  });
  const queryString = search.toString();
  return queryString ? `${path}?${queryString}` : path;
}

export async function apiGet<T>(path: string, query?: Record<string, string | number | undefined>): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${withQuery(path, query)}`);
  if (!response.ok) throw new Error(`GET ${path} failed: ${response.status}`);
  return response.json() as Promise<T>;
}

export async function apiPost<T>(path: string, body: unknown): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!response.ok) {
    throw new Error((await response.text()) || `POST ${path} failed: ${response.status}`);
  }
  return response.json() as Promise<T>;
}

export async function apiPatch<T>(path: string, body: unknown): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!response.ok) {
    throw new Error((await response.text()) || `PATCH ${path} failed: ${response.status}`);
  }
  return response.json() as Promise<T>;
}

export async function apiDelete<T>(path: string): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: 'DELETE',
  });
  if (!response.ok) {
    throw new Error((await response.text()) || `DELETE ${path} failed: ${response.status}`);
  }
  return response.json() as Promise<T>;
}

export async function uploadScreenshot(file: File) {
  const formData = new FormData();
  formData.append('file', file);
  const response = await fetch(`${API_BASE_URL}/admin/uploads/screenshot`, {
    method: 'POST',
    body: formData,
  });
  if (!response.ok) {
    throw new Error((await response.text()) || `Upload failed: ${response.status}`);
  }
  const payload = await response.json() as { url: string; sizeBytes: number };
  const base = API_BASE_URL.replace(/\/api\/v1$/, '');
  return {
    ...payload,
    absoluteUrl: payload.url.startsWith('http') ? payload.url : `${base}${payload.url}`,
  };
}

export function getApps(query?: Record<string, string | number | undefined>) {
  return apiGet<PaginatedResult<AppSummary>>('/apps', query);
}

export function getAppDetail(slug: string) {
  return apiGet<AppDetail>(`/apps/${slug}`);
}

export function getPatterns() {
  return apiGet<{ items: PatternSummary[]; total: number }>('/patterns');
}

export function getPatternDetail(slug: string) {
  return apiGet<PatternDetail>(`/patterns/${slug}`);
}

export function getDiscussions(query?: Record<string, string | number | undefined>) {
  return apiGet<PaginatedResult<DiscussionItem>>('/discussions', query);
}

export function getDiscussion(id: string) {
  return apiGet<DiscussionItem>(`/discussions/${id}`);
}

export function createComment(id: string, body: { authorName: string; content: string; replyToCommentId?: string }) {
  return apiPost<DiscussionItem['comments'][number]>(`/discussions/${id}/comments`, body);
}

export function createDiscussion(body: CreateDiscussionPayload) {
  return apiPost<DiscussionItem>('/discussions', body);
}

export function likeDiscussion(id: string) {
  return apiPost<DiscussionItem>(`/discussions/${id}/like`, {});
}

export function createSubmission(body: SubmissionPayload) {
  return apiPost<SubmissionRecord>('/submissions', body);
}

export function subscribeDigest(email: string) {
  return apiPost<{ success: boolean }>('/subscribe', { email });
}

export function getAdminSubmissions(status?: string) {
  return apiGet<SubmissionRecord[]>('/admin/submissions', status ? { status } : undefined);
}

export function reviewSubmission(id: string, body: ReviewSubmissionPayload) {
  return apiPost<{ submission: SubmissionRecord; createdApp: AppSummary | null }>(`/admin/submissions/${id}/review`, body);
}

export function deleteSubmission(id: string) {
  return apiDelete<{ success: boolean }>(`/admin/submissions/${id}`);
}

export function getAdminApps() {
  return apiGet<AdminAppRecord[]>('/admin/apps');
}

export function createAdminApp(body: Partial<AdminAppRecord> & Record<string, unknown>) {
  return apiPost<AdminAppRecord>('/admin/apps', body);
}

export function updateAdminApp(id: string, body: Partial<AdminAppRecord> & Record<string, unknown>) {
  return apiPatch<AdminAppRecord>(`/admin/apps/${id}`, body);
}

export function deleteAdminApp(id: string) {
  return apiDelete<{ success: boolean }>(`/admin/apps/${id}`);
}

export function getAdminPatterns() {
  return apiGet<AdminPatternRecord[]>('/admin/patterns');
}

export function createAdminPattern(body: Partial<AdminPatternRecord>) {
  return apiPost<AdminPatternRecord>('/admin/patterns', body);
}

export function updateAdminPattern(id: string, body: Partial<AdminPatternRecord>) {
  return apiPatch<AdminPatternRecord>(`/admin/patterns/${id}`, body);
}

export function deleteAdminPattern(id: string) {
  return apiDelete<{ success: boolean }>(`/admin/patterns/${id}`);
}

export function getAdminDiscussions() {
  return apiGet<AdminDiscussionRecord[]>('/admin/discussions');
}

export function updateAdminDiscussion(id: string, body: { title?: string; likesCount?: number }) {
  return apiPatch<AdminDiscussionRecord>(`/admin/discussions/${id}`, body);
}

export function deleteAdminDiscussion(id: string) {
  return apiDelete<{ success: boolean }>(`/admin/discussions/${id}`);
}

export function getAdminSubscribers() {
  return apiGet<SubscriberRecord[]>('/admin/subscribers');
}

export function createAdminSubscriber(email: string) {
  return apiPost<SubscriberRecord>('/admin/subscribers', { email });
}

export function updateAdminSubscriber(id: string, email: string) {
  return apiPatch<SubscriberRecord>(`/admin/subscribers/${id}`, { email });
}

export function deleteAdminSubscriber(id: string) {
  return apiDelete<{ success: boolean }>(`/admin/subscribers/${id}`);
}
