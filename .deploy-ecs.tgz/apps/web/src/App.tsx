import { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  ArrowRight,
  Calendar,
  CheckCircle2,
  ChevronRight,
  Database,
  DollarSign,
  Filter,
  Github,
  Globe,
  Heart,
  Info,
  Layers,
  Layout,
  Menu,
  MessageCircle,
  MessageSquare,
  PlusCircle,
  Search,
  Share2,
  TrendingUp,
  Twitter,
  Users,
  X,
} from 'lucide-react';
import React from 'react';
import {
  BrowserRouter as Router,
  Link,
  Route,
  Routes,
  useLocation,
  useNavigate,
  useParams,
} from 'react-router-dom';
import {
  AdminAppRecord,
  AdminPatternRecord,
  createAdminApp,
  createAdminPattern,
  createAdminSubscriber,
  AppDetail,
  AppSummary,
  createComment,
  createDiscussion,
  createSubmission,
  deleteAdminApp,
  deleteAdminDiscussion,
  deleteAdminPattern,
  deleteAdminSubscriber,
  deleteSubmission,
  DiscussionItem,
  getAppDetail,
  getAdminApps,
  getAdminDiscussions,
  getAdminSubscribers,
  getApps,
  getDiscussion,
  getDiscussions,
  getAdminPatterns,
  getPatternDetail,
  getPatterns,
  getAdminSubmissions,
  likeDiscussion,
  PatternDetail,
  PatternSummary,
  SubmissionRecord,
  SubmissionPayload,
  updateAdminApp,
  updateAdminDiscussion,
  updateAdminPattern,
  updateAdminSubscriber,
  uploadScreenshot,
  reviewSubmission,
  SubscriberRecord,
} from './lib/api';
import { AssetBundlePanel, AssetPreviewKey } from './components/AssetBundlePanel';
import { cn } from './utils';

const pricingLabelMap: Record<string, string> = {
  FREE: '免费',
  FREEMIUM: '免费增值',
  PAID: '付费',
  USAGE_BASED: '按量付费',
};

const targetTypeMap: Record<'APP' | 'PATTERN', string> = {
  APP: '应用',
  PATTERN: '模式',
};

const breakdownLabelMap: Record<string, string> = {
  painAndPersona: '痛点与人群',
  triggerScene: '触发场景',
  corePromise: '核心承诺',
  ahaMoment: '首次惊喜',
  retentionLoop: '留存循环',
  growthEngine: '增长引擎',
  monetization: '变现方式',
  moat: '护城河',
};

const trustSignalToneMap: Record<string, string> = {
  开源: 'bg-emerald-50 text-emerald-700 border-emerald-100',
  可在线体验: 'bg-sky-50 text-sky-700 border-sky-100',
  有收入截图: 'bg-amber-50 text-amber-700 border-amber-100',
  有用户故事: 'bg-violet-50 text-violet-700 border-violet-100',
};

function getTrustSignalClass(signal: string) {
  return trustSignalToneMap[signal] || 'bg-brand-ink/5 text-brand-ink/60 border-brand-line/10';
}

const LIKED_DISCUSSIONS_STORAGE_KEY = 'hvc-liked-discussions';

function getLikedDiscussionIds() {
  if (typeof window === 'undefined') return [];
  try {
    const raw = window.localStorage.getItem(LIKED_DISCUSSIONS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter((value): value is string => typeof value === 'string') : [];
  } catch {
    return [];
  }
}

function saveLikedDiscussionIds(ids: string[]) {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(LIKED_DISCUSSIONS_STORAGE_KEY, JSON.stringify(ids));
}

const Home = () => {
  const [apps, setApps] = useState<AppSummary[]>([]);

  useEffect(() => {
    getApps({ sort: 'latest', page: 1, pageSize: 4 })
      .then((result) => setApps(result.items))
      .catch(() => setApps([]));
  }, []);

  const homeStats = useMemo(
    () => [
      { label: '最近新增', value: `${apps.length}`, note: '首屏展示的最新案例' },
      { label: '覆盖分类', value: `${new Set(apps.map((app) => app.category)).size}`, note: '来自真实业务场景' },
      { label: '可信标签', value: `${new Set(apps.flatMap((app) => app.trustSignals)).size}`, note: '用于快速判断可信度' },
    ],
    [apps],
  );

  return (
    <div className="space-y-16 py-12">
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-8">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
          <h1 className="text-5xl md:text-7xl font-serif italic tracking-tight leading-tight">
            做出更好的 <span className="not-italic font-sans font-bold">产品</span> 决策
          </h1>
          <p className="text-xl text-brand-ink/60 max-w-2xl mx-auto font-light">
            收录已上线产品，拆解商业逻辑、复用模式与社区讨论，帮助你更快理解什么值得做、为什么能做成。
          </p>
        </motion.div>

        <div className="max-w-2xl mx-auto relative group">
          <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-brand-ink/40" />
          </div>
          <input
            type="text"
            placeholder="搜索产品、模式或讨论..."
            className="w-full pl-12 pr-4 py-4 bg-white border border-brand-line/10 rounded-2xl shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-ink/5 focus:border-brand-ink transition-all"
          />
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-3 gap-4">
        {homeStats.map((item) => (
          <div key={item.label} className="rounded-3xl border border-brand-line/10 bg-white px-6 py-5 shadow-sm">
            <div className="text-[10px] font-mono uppercase tracking-[0.24em] text-brand-ink/35">{item.label}</div>
            <div className="mt-3 text-3xl font-bold tracking-tight">{item.value}</div>
            <div className="mt-1 text-sm text-brand-ink/45">{item.note}</div>
          </div>
        ))}
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-3 gap-8">
        {[
          { title: '产品情报', desc: '按数据库视角查看已上线产品与核心信息。', icon: Layout, link: '/directory' },
          { title: '模式库', desc: '提炼可复用的增长、定价与工作流模式。', icon: Layers, link: '/patterns' },
          { title: '社区讨论', desc: '围绕产品判断、增长策略与拆解结论讨论。', icon: MessageSquare, link: '/discussions' },
        ].map((item) => (
          <Link key={item.title} to={item.link}>
            <motion.div whileHover={{ y: -5 }} className="p-8 bg-white border border-brand-line/5 rounded-3xl shadow-sm hover:shadow-md transition-all space-y-4">
              <div className="w-12 h-12 bg-brand-ink/5 rounded-2xl flex items-center justify-center">
                <item.icon className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold">{item.title}</h3>
              <p className="text-brand-ink/60">{item.desc}</p>
            </motion.div>
          </Link>
        ))}
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex justify-between items-end">
          <h2 className="text-3xl font-serif italic">最新拆解</h2>
          <Link to="/directory" className="text-sm font-bold flex items-center gap-2 hover:gap-3 transition-all">
            查看全部 <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {apps.map((app) => (
            <Link key={app.id} to={`/intelligence/${app.slug}`}>
              <div className="group rounded-3xl border border-brand-line/10 bg-white p-5 shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md cursor-pointer">
                <div className="flex min-h-[280px] flex-col">
                  <div className="rounded-3xl border border-brand-line/10 bg-brand-ink/[0.02] p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex h-11 w-11 items-center justify-center rounded-2xl border border-brand-line/10 bg-white text-lg font-bold text-brand-ink shadow-sm">
                        {app.name.slice(0, 1)}
                      </div>
                      <span className="rounded-full border border-brand-line/10 bg-white px-3 py-1 text-[10px] font-semibold text-brand-ink/55">
                        {app.category}
                      </span>
                    </div>
                    <div className="mt-4 space-y-1.5">
                      <div className="text-[10px] font-mono uppercase tracking-[0.24em] text-brand-ink/30">省下的 30 秒</div>
                      <p className="text-xs leading-6 text-brand-ink/55 line-clamp-2">
                        {app.saveTimeLabel}
                      </p>
                    </div>
                  </div>
                  <div className="mt-5 flex flex-1 flex-col">
                    <div className="space-y-2">
                      <h4 className="text-xl font-bold tracking-tight text-brand-ink">{app.name}</h4>
                      <p className="text-sm leading-7 text-brand-ink/58 line-clamp-2">
                        {app.tagline || '已收录，待补充一句话描述'}
                      </p>
                    </div>
                    <div className="mt-4 rounded-2xl bg-brand-ink/[0.02] px-4 py-3">
                      <div className="text-[10px] font-mono uppercase tracking-[0.24em] text-brand-ink/28">亮点钩子</div>
                      <p className="mt-2 text-xs leading-6 text-brand-ink/50 line-clamp-2">{app.hookAngle}</p>
                    </div>
                    <div className="mt-4 flex flex-wrap gap-1.5">
                      {app.trustSignals.length > 0 ? app.trustSignals.slice(0, 2).map((signal) => (
                        <span
                          key={signal}
                          className={cn(
                            'inline-flex items-center rounded-full border px-2.5 py-1 text-[10px] font-semibold',
                            getTrustSignalClass(signal),
                          )}
                        >
                          {signal}
                        </span>
                      )) : (
                        <span className="text-[11px] text-brand-ink/28">待验证</span>
                      )}
                    </div>
                    <div className="mt-auto pt-5 flex items-center justify-between text-[11px] font-semibold text-brand-ink/35">
                      <span>{app.pattern?.name || '未归类模式'}</span>
                      <span className="inline-flex items-center gap-1 transition-all group-hover:gap-1.5 group-hover:text-brand-ink/55">
                        查看拆解
                        <ArrowRight className="h-3.5 w-3.5" />
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
};

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const navItems = [
    { name: '产品库', path: '/directory' },
    { name: '模式库', path: '/patterns' },
    { name: '讨论区', path: '/discussions' },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-[#F8F7F4]/80 backdrop-blur-md border-b border-brand-line/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20">
          <div className="flex items-center gap-8">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-10 h-10 bg-brand-ink rounded-xl flex items-center justify-center text-brand-bg font-bold text-xl">V</div>
              <span className="text-xl font-bold tracking-tighter">helloVibeCoding</span>
            </Link>

            <div className="hidden md:flex items-center gap-6">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={cn(
                    'text-sm font-medium transition-colors hover:text-brand-ink',
                    location.pathname.startsWith(item.path) ? 'text-brand-ink' : 'text-brand-ink/50',
                  )}
                >
                  {item.name}
                </Link>
              ))}
            </div>
          </div>

          <div className="hidden md:flex items-center gap-4">
            <Link to="/submit" className="flex items-center gap-2 px-4 py-2 bg-brand-ink text-brand-bg rounded-xl text-sm font-bold hover:opacity-90 transition-opacity">
              <PlusCircle className="h-4 w-4" />
              提交产品
            </Link>
          </div>

          <div className="md:hidden flex items-center">
            <button onClick={() => setIsOpen(!isOpen)} className="p-2" aria-label="切换菜单">
              {isOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-b border-brand-line/5 overflow-hidden"
          >
            <div className="px-4 pt-2 pb-6 space-y-2">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setIsOpen(false)}
                  className="block px-3 py-4 text-base font-medium text-brand-ink/70 hover:text-brand-ink hover:bg-brand-ink/5 rounded-xl"
                >
                  {item.name}
                </Link>
              ))}
              <Link to="/submit" onClick={() => setIsOpen(false)} className="block px-3 py-4 text-base font-bold text-brand-ink">
                提交产品
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Footer = () => (
  <footer className="bg-white border-t border-brand-line/5 py-12 mt-24">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-12">
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-brand-ink rounded-lg flex items-center justify-center text-brand-bg font-bold text-lg">V</div>
          <span className="text-lg font-bold tracking-tighter">helloVibeCoding</span>
        </div>
        <p className="text-sm text-brand-ink/50 leading-relaxed">
          面向产品与增长团队的情报平台。<br />
          通过已上线产品理解真实商业信号。
        </p>
      </div>

      <div>
        <h4 className="font-bold mb-4">浏览</h4>
        <ul className="space-y-2 text-sm text-brand-ink/50">
          <li><Link to="/directory" className="hover:text-brand-ink">产品库</Link></li>
          <li><Link to="/patterns" className="hover:text-brand-ink">模式库</Link></li>
          <li><Link to="/discussions" className="hover:text-brand-ink">讨论区</Link></li>
        </ul>
      </div>

      <div>
        <h4 className="font-bold mb-4">操作</h4>
        <ul className="space-y-2 text-sm text-brand-ink/50">
          <li><Link to="/submit" className="hover:text-brand-ink">提交产品</Link></li>
          <li><a href="http://localhost:3001/api/v1/docs" className="hover:text-brand-ink" target="_blank" rel="noreferrer">API 文档</a></li>
          <li><Link to="/admin" className="hover:text-brand-ink">审核台</Link></li>
        </ul>
      </div>

      <div>
        <h4 className="font-bold mb-4">关注</h4>
        <div className="flex gap-4">
          <a href="#" className="p-2 bg-brand-ink/5 rounded-lg hover:bg-brand-ink/10 transition-colors" aria-label="Twitter">
            <Twitter className="h-5 w-5" />
          </a>
          <a href="#" className="p-2 bg-brand-ink/5 rounded-lg hover:bg-brand-ink/10 transition-colors" aria-label="Github">
            <Github className="h-5 w-5" />
          </a>
        </div>
      </div>
    </div>
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 pt-8 border-t border-brand-line/5 text-center text-xs text-brand-ink/30">
      © {new Date().getFullYear()} helloVibeCoding. All rights reserved.
    </div>
  </footer>
);

const DirectoryPage = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPattern, setSelectedPattern] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('全部');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [apps, setApps] = useState<AppSummary[]>([]);
  const [patterns, setPatterns] = useState<PatternSummary[]>([]);

  useEffect(() => {
    getPatterns().then((result) => setPatterns(result.items)).catch(() => setPatterns([]));
  }, []);

  useEffect(() => {
    getApps({ search: searchQuery, pattern: selectedPattern, page: 1, pageSize: 24, sort: 'hot' })
      .then((result) => setApps(result.items))
      .catch(() => setApps([]));
  }, [searchQuery, selectedPattern]);

  const categoryOptions = useMemo(
    () => ['全部', ...Array.from(new Set(apps.map((app) => app.category).filter(Boolean)))],
    [apps],
  );

  const visibleApps = useMemo(
    () => apps.filter((app) => selectedCategory === '全部' || app.category === selectedCategory),
    [apps, selectedCategory],
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-4xl font-serif italic">产品情报库</h1>
          <p className="text-brand-ink/50">从一句价值、适用人群和可信信号，快速判断哪些产品值得深挖</p>
        </div>
        <div className="flex items-center gap-4 w-full md:w-auto">
          <div className="relative flex-grow md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-brand-ink/30" />
            <input
              type="text"
              placeholder="搜索产品..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white border border-brand-line/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-ink/5"
            />
          </div>
          <div className="relative">
            <select
              value={selectedPattern}
              onChange={(e) => setSelectedPattern(e.target.value)}
              className="appearance-none pl-4 pr-10 py-2 bg-white border border-brand-line/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-ink/5"
            >
              <option value="">全部模式</option>
              {patterns.map((pattern) => (
                <option key={pattern.id} value={pattern.slug}>{pattern.name}</option>
              ))}
            </select>
            <Filter className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-brand-ink/30 pointer-events-none" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[
          { label: '已收录产品', value: `${visibleApps.length}`, note: '当前筛选结果' },
          { label: '覆盖分类', value: `${categoryOptions.length - 1}`, note: '按真实场景归类' },
          { label: '平均热度', value: visibleApps.length ? `${Math.round(visibleApps.reduce((sum, app) => sum + app.heatScore, 0) / visibleApps.length)}` : '0', note: '便于初筛优先级' },
        ].map((item) => (
          <div key={item.label} className="rounded-3xl border border-brand-line/10 bg-white p-5 shadow-sm">
            <div className="text-[10px] font-mono uppercase tracking-[0.24em] text-brand-ink/35">{item.label}</div>
            <div className="mt-3 text-3xl font-bold tracking-tight">{item.value}</div>
            <div className="mt-1 text-sm text-brand-ink/45">{item.note}</div>
          </div>
        ))}
      </div>

      <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
        {categoryOptions.map((category) => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={cn(
              'px-4 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap border',
              selectedCategory === category
                ? 'bg-brand-ink text-brand-bg border-brand-ink'
                : 'bg-white border-brand-line/10 text-brand-ink/60 hover:border-brand-ink/30',
            )}
          >
            {category}
          </button>
        ))}
      </div>

      <div className="lg:hidden space-y-4">
        {visibleApps.map((app) => (
          <div key={app.id} className="rounded-3xl border border-brand-line/10 bg-white shadow-sm overflow-hidden">
            <button
              type="button"
              onClick={() => setExpandedId((current) => (current === app.id ? null : app.id))}
              className="w-full p-5 text-left"
              aria-expanded={expandedId === app.id}
            >
              <div className="flex items-start gap-4">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-brand-ink/5 font-bold">{app.name.slice(0, 1)}</div>
                <div className="min-w-0 flex-1 space-y-2">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="font-bold text-brand-ink">{app.name}</div>
                      <div className="mt-1 text-xs text-brand-ink/45 line-clamp-2">{app.tagline || '待补充一句话描述'}</div>
                    </div>
                    <span className={cn(
                      'mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-xl border border-brand-line/10 bg-white text-brand-ink/40 transition-transform',
                      expandedId === app.id ? 'rotate-90' : '',
                    )}>
                      <ChevronRight className="h-4 w-4" />
                    </span>
                  </div>
                  <div className="text-xs text-brand-ink/70">{app.saveTimeLabel}</div>
                  <div className="flex flex-wrap gap-2">
                    <span className="rounded-full bg-brand-ink/5 px-3 py-1 text-[11px] font-medium text-brand-ink/65">{app.category}</span>
                    <span className="rounded-full bg-brand-ink/5 px-3 py-1 text-[11px] font-medium text-brand-ink/55">{pricingLabelMap[app.pricing] || app.pricing}</span>
                  </div>
                </div>
              </div>
            </button>

            <AnimatePresence initial={false}>
              {expandedId === app.id ? (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden border-t border-brand-line/5 bg-brand-ink/[0.02]"
                >
                  <div className="space-y-4 px-5 py-5">
                    <div>
                      <div className="text-[10px] font-mono uppercase tracking-[0.24em] text-brand-ink/35">亮点钩子</div>
                      <p className="mt-2 text-sm leading-relaxed text-brand-ink/70">{app.hookAngle}</p>
                    </div>
                    <div>
                      <div className="text-[10px] font-mono uppercase tracking-[0.24em] text-brand-ink/35">目标用户</div>
                      <p className="mt-2 text-sm leading-relaxed text-brand-ink/70">{app.targetPersona}</p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {app.trustSignals.length > 0 ? app.trustSignals.map((signal) => (
                        <span
                          key={signal}
                          className={cn('inline-flex items-center rounded-full border px-2.5 py-1 text-[10px] font-semibold', getTrustSignalClass(signal))}
                        >
                          {signal}
                        </span>
                      )) : <span className="text-xs text-brand-ink/30">待验证</span>}
                    </div>
                    <Link
                      to={`/intelligence/${app.slug}`}
                      className="inline-flex items-center gap-2 rounded-2xl bg-brand-ink px-4 py-2 text-xs font-bold text-brand-bg transition-opacity hover:opacity-90"
                    >
                      查看完整拆解
                      <ArrowRight className="h-3.5 w-3.5" />
                    </Link>
                  </div>
                </motion.div>
              ) : null}
            </AnimatePresence>
          </div>
        ))}
      </div>

      <div className="hidden lg:block bg-white border border-brand-line/10 rounded-3xl overflow-hidden shadow-sm">
        <div className="grid grid-cols-[70px_minmax(0,2fr)_minmax(0,1fr)_minmax(0,1fr)_minmax(0,0.9fr)_minmax(0,1.1fr)_56px] p-4 bg-brand-ink/5 border-b border-brand-line/10">
          <span className="col-header">图标</span>
          <span className="col-header">产品名称</span>
          <span className="col-header">分类</span>
          <span className="col-header">模式</span>
          <span className="col-header">定价</span>
          <span className="col-header">可信度</span>
          <span className="col-header text-right">展开</span>
        </div>

        <div className="divide-y divide-brand-line/5">
          {visibleApps.map((app) => (
            <div key={app.id}>
              <motion.button
                type="button"
                whileHover={{ backgroundColor: 'rgba(20, 20, 20, 0.02)' }}
                onClick={() => setExpandedId((current) => (current === app.id ? null : app.id))}
                className="grid w-full grid-cols-[70px_minmax(0,2fr)_minmax(0,1fr)_minmax(0,1fr)_minmax(0,0.9fr)_minmax(0,1.1fr)_56px] p-4 items-center gap-3 text-left transition-colors cursor-pointer"
                aria-expanded={expandedId === app.id}
              >
                <div className="w-10 h-10 rounded-xl bg-brand-ink/5 flex items-center justify-center font-bold">{app.name.slice(0, 1)}</div>
                <div className="min-w-0 flex flex-col gap-1.5">
                  <span className="font-bold text-brand-ink">{app.name}</span>
                  <span className="text-xs text-brand-ink/45 line-clamp-1">{app.tagline || '待补充一句话描述'}</span>
                  <span className="text-xs text-brand-ink/70 line-clamp-1">省下的 30 秒：{app.saveTimeLabel}</span>
                </div>
                <div className="min-w-0">
                  <span className="inline-flex rounded-full bg-brand-ink/5 px-3 py-1 text-xs font-medium text-brand-ink/65">{app.category}</span>
                </div>
                <div className="min-w-0">
                  <div className="text-sm text-brand-ink/60 line-clamp-1">{app.pattern?.name || '未归类'}</div>
                  <div className="mt-1 text-[11px] text-brand-ink/35 line-clamp-1">{app.coldStartHighlight || '待补充冷启动亮点'}</div>
                </div>
                <div className="min-w-0">
                  <div className="data-value">{pricingLabelMap[app.pricing] || app.pricing}</div>
                  <div className="mt-1 text-[11px] text-brand-ink/35">热度 {app.heatScore}</div>
                </div>
                <div className="min-w-0 flex flex-wrap gap-1.5">
                  {app.trustSignals.length > 0 ? (
                    app.trustSignals.slice(0, 2).map((signal) => (
                      <span
                        key={signal}
                        className={cn(
                          'inline-flex items-center rounded-full border px-2.5 py-1 text-[10px] font-semibold',
                          getTrustSignalClass(signal),
                        )}
                      >
                        {signal}
                      </span>
                    ))
                  ) : (
                    <span className="text-xs text-brand-ink/30">待验证</span>
                  )}
                </div>
                <div className="flex justify-end">
                  <span className={cn(
                    'flex h-9 w-9 items-center justify-center rounded-xl border border-brand-line/10 bg-white text-brand-ink/40 transition-transform',
                    expandedId === app.id ? 'rotate-90' : '',
                  )}>
                    <ChevronRight className="h-4 w-4" />
                  </span>
                </div>
              </motion.button>

              <AnimatePresence initial={false}>
                {expandedId === app.id ? (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden border-t border-brand-line/5 bg-brand-ink/[0.02]"
                  >
                    <div className="grid gap-4 px-5 py-5 md:grid-cols-[minmax(0,1.5fr)_minmax(0,1.1fr)_auto]">
                      <div className="space-y-3">
                        <div className="text-[10px] font-mono uppercase tracking-[0.24em] text-brand-ink/35">快速判断</div>
                        <p className="text-sm leading-relaxed text-brand-ink/75">{app.saveTimeLabel}</p>
                        <p className="text-sm leading-relaxed text-brand-ink/55">{app.hookAngle}</p>
                      </div>
                      <div className="space-y-3">
                        <div className="text-[10px] font-mono uppercase tracking-[0.24em] text-brand-ink/35">适用人群 / 渠道</div>
                        <p className="text-sm leading-relaxed text-brand-ink/75">{app.targetPersona}</p>
                        <div className="flex flex-wrap gap-2">
                          {app.channels.slice(0, 4).map((channel) => (
                            <span key={channel} className="rounded-full border border-brand-line/10 bg-white px-3 py-1 text-[11px] text-brand-ink/55">
                              {channel}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div className="flex flex-col items-start gap-3 md:items-end">
                        <div className="text-[10px] font-mono uppercase tracking-[0.24em] text-brand-ink/35">动作</div>
                        <Link
                          to={`/intelligence/${app.slug}`}
                          className="inline-flex items-center gap-2 rounded-2xl bg-brand-ink px-4 py-2 text-xs font-bold text-brand-bg transition-opacity hover:opacity-90"
                        >
                          查看完整拆解
                          <ArrowRight className="h-3.5 w-3.5" />
                        </Link>
                      </div>
                    </div>
                  </motion.div>
                ) : null}
              </AnimatePresence>
            </div>
          ))}
          {visibleApps.length === 0 ? (
            <div className="p-10 text-center text-sm text-brand-ink/40">当前筛选下暂无产品。</div>
          ) : null}
        </div>
      </div>
    </div>
  );
};

const IntelligencePage = () => {
  const { slug } = useParams();
  const [app, setApp] = useState<AppDetail | null>(null);
  const [activeTab, setActiveTab] = useState('概览');
  const [activeAssetPreview, setActiveAssetPreview] = useState<AssetPreviewKey>('agents');
  const [copiedAssetPreview, setCopiedAssetPreview] = useState<AssetPreviewKey | null>(null);

  useEffect(() => {
    if (!slug) return;
    getAppDetail(slug).then(setApp).catch(() => setApp(null));
  }, [slug]);

  useEffect(() => {
    if (!app) return;
    if (app.buildAssets.hasAgentsTemplate) {
      setActiveAssetPreview('agents');
    } else if (app.buildAssets.hasSpecTemplate) {
      setActiveAssetPreview('spec');
    } else if (app.buildAssets.hasPromptPack) {
      setActiveAssetPreview('prompt');
    }
    setCopiedAssetPreview(null);
  }, [app]);

  if (!app) return <div className="p-20 text-center">未找到该产品。</div>;

  const metrics = [
    { label: '分类', value: app.category, icon: Layout },
    { label: '目标用户', value: app.targetPersona, icon: Users },
    { label: '亮点钩子', value: app.hookAngle, icon: Info },
    { label: '热度 / 难度', value: `${app.heatScore} / ${app.difficulty}`, icon: TrendingUp },
  ];

  const teardownSections = app.teardown
    ? [
        { label: '痛点判断', value: app.teardown.painSummary, meta: app.teardown.painScore },
        { label: '触发场景', value: app.teardown.triggerScene },
        { label: '核心承诺', value: app.teardown.corePromise },
        { label: '核心循环', value: app.teardown.coreLoop },
        { label: 'MVP 功能', value: app.teardown.mvpScope },
        {
          label: '数据 / AI 点',
          value: [app.teardown.dataInput, app.teardown.dataOutput, app.teardown.faultTolerance].filter(Boolean).join(' · '),
        },
        { label: '冷启动策略', value: app.teardown.coldStartStrategy },
        { label: '定价逻辑', value: app.teardown.pricingLogic },
        { label: '竞品差异', value: app.teardown.competitorDelta },
        { label: '风险', value: app.teardown.riskNotes },
      ]
    : [];
  const assetEntries = [
    {
      key: 'agents' as const,
      label: 'AGENTS.md',
      available: app.buildAssets.hasAgentsTemplate,
      content: app.buildAssets.agentsTemplate || '',
      desc: '给 coding agent 的协作协议',
    },
    {
      key: 'spec' as const,
      label: 'SPEC',
      available: app.buildAssets.hasSpecTemplate,
      content: app.buildAssets.specTemplate || '',
      desc: '接口、数据模型与异常流',
    },
    {
      key: 'prompt' as const,
      label: 'Prompt Pack',
      available: app.buildAssets.hasPromptPack,
      content: app.buildAssets.promptPack || '',
      desc: '沉淀可复用提问模版',
    },
  ];
  const handleCopyAsset = async () => {
    const activeAsset = assetEntries.find((asset) => asset.key === activeAssetPreview) || assetEntries[0];
    if (!activeAsset?.available || !activeAsset.content) return;
    try {
      await navigator.clipboard.writeText(activeAsset.content);
      setCopiedAssetPreview(activeAsset.key);
      window.setTimeout(() => setCopiedAssetPreview((current) => (current === activeAsset.key ? null : current)), 1200);
    } catch {
      setCopiedAssetPreview(null);
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F7F4]">
      <div className="bg-white border-b border-brand-line/5 pt-12 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <Link to="/directory" className="inline-flex items-center gap-2 text-sm font-bold text-brand-ink/40 hover:text-brand-ink transition-colors">
            <ArrowRight className="h-4 w-4 rotate-180" /> 返回产品库
          </Link>

          <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
            <div className="flex items-center gap-6">
              <div className="w-24 h-24 bg-brand-ink/5 rounded-3xl flex items-center justify-center p-4 border border-brand-line/5 shadow-sm text-4xl font-bold">
                {app.name.slice(0, 1)}
              </div>
              <div className="space-y-2">
                <h1 className="text-4xl font-bold tracking-tight">{app.name}</h1>
                <p className="text-lg text-brand-ink/60 font-light">{app.tagline || '待补充一句话描述'}</p>
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <span className="inline-flex rounded-full bg-brand-ink px-3 py-1 text-[11px] font-semibold text-brand-bg">
                    {app.category}
                  </span>
                  {app.trustSignals.map((signal) => (
                    <span
                      key={signal}
                      className={cn(
                        'inline-flex items-center rounded-full border px-2.5 py-1 text-[10px] font-semibold',
                        getTrustSignalClass(signal),
                      )}
                    >
                      {signal}
                    </span>
                  ))}
                </div>
                <div className="flex gap-4 pt-2">
                  <Globe className="h-5 w-5 text-brand-ink/30" />
                  <Twitter className="h-5 w-5 text-brand-ink/30" />
                  <Github className="h-5 w-5 text-brand-ink/30" />
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <button className="px-6 py-3 bg-brand-ink text-brand-bg rounded-2xl font-bold hover:opacity-90 transition-opacity">关注动态</button>
              <button className="p-3 bg-brand-ink/5 rounded-2xl hover:bg-brand-ink/10 transition-colors" aria-label="更多信息">
                <Info className="h-5 w-5" />
              </button>
            </div>
          </div>

          <div className="flex gap-8 border-b border-brand-line/5 pt-4 overflow-x-auto">
            {['概览', '拆解', '模式', '讨论', '资产'].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={cn('pb-4 text-sm font-bold transition-all relative whitespace-nowrap', activeTab === tab ? 'text-brand-ink' : 'text-brand-ink/40 hover:text-brand-ink/60')}
              >
                {tab}
                {activeTab === tab && <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-brand-ink" />}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-12">
          <section className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {metrics.map((stat) => (
              <div key={stat.label} className="p-6 bg-white border border-brand-line/5 rounded-3xl space-y-3 shadow-sm">
                <div className="flex items-center gap-2 text-brand-ink/40">
                  <stat.icon className="h-4 w-4" />
                  <span className="text-[10px] font-mono uppercase tracking-widest">{stat.label}</span>
                </div>
                <div className="text-base md:text-lg font-bold leading-tight">{stat.value}</div>
              </div>
            ))}
          </section>

          {activeTab === '概览' ? (
            <>
              <section className="bg-white border border-brand-line/5 rounded-3xl p-8 space-y-6 shadow-sm">
                <div className="space-y-2">
                  <h2 className="text-2xl font-serif italic">一句判断</h2>
                  <p className="text-brand-ink/70 leading-relaxed">
                    {app.name} 最直接的价值，不是更复杂的功能，而是替用户在关键时刻省下这 30 秒：
                  </p>
                </div>
                <div className="rounded-3xl border border-brand-line/10 bg-brand-ink/[0.02] p-6">
                  <p className="text-lg font-semibold leading-relaxed text-brand-ink">{app.saveTimeLabel}</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="rounded-2xl border border-brand-line/10 p-5">
                    <div className="text-[10px] font-mono uppercase tracking-[0.24em] text-brand-ink/35">目标用户</div>
                    <p className="mt-3 text-sm leading-relaxed text-brand-ink/75">{app.targetPersona}</p>
                  </div>
                  <div className="rounded-2xl border border-brand-line/10 p-5">
                    <div className="text-[10px] font-mono uppercase tracking-[0.24em] text-brand-ink/35">亮点钩子</div>
                    <p className="mt-3 text-sm leading-relaxed text-brand-ink/75">{app.hookAngle}</p>
                  </div>
                  <div className="rounded-2xl border border-brand-line/10 p-5">
                    <div className="text-[10px] font-mono uppercase tracking-[0.24em] text-brand-ink/35">渠道覆盖</div>
                    <p className="mt-3 text-sm leading-relaxed text-brand-ink/75">{app.channels.join(' / ') || '待补充'}</p>
                  </div>
                </div>
              </section>

              {app.screenshotUrls.length > 0 ? (
                <section className="space-y-6">
                  <h2 className="text-2xl font-serif italic">产品截图</h2>
                  {app.screenshotUrls.map((url, index) => (
                    <div key={url} className="relative bg-white border border-brand-line/5 rounded-3xl overflow-hidden shadow-sm group">
                      <img
                        src={url}
                        alt={`${app.name} 截图 ${index + 1}`}
                        className="w-full h-auto max-h-[640px] object-cover"
                        referrerPolicy="no-referrer"
                      />
                      <div className="p-4 bg-white/80 backdrop-blur-sm border-t border-brand-line/5 text-center text-sm font-medium">
                        {index === 0 ? `${app.name} 关键界面` : `截图 ${index + 1}`}
                      </div>
                    </div>
                  ))}
                </section>
              ) : null}

            </>
          ) : null}

          {activeTab === '拆解' ? (
            <div className="space-y-8">
              <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="rounded-3xl border border-brand-line/5 bg-white p-6 shadow-sm">
                  <div className="text-[10px] font-mono uppercase tracking-[0.24em] text-brand-ink/35">亮点钩子</div>
                  <p className="mt-3 text-sm leading-relaxed text-brand-ink/75">{app.hookAngle}</p>
                </div>
                <div className="rounded-3xl border border-brand-line/5 bg-white p-6 shadow-sm">
                  <div className="text-[10px] font-mono uppercase tracking-[0.24em] text-brand-ink/35">冷启动线索</div>
                  <p className="mt-3 text-sm leading-relaxed text-brand-ink/75">{app.teardown?.coldStartStrategy || '待补充冷启动策略。'}</p>
                </div>
                <div className="rounded-3xl border border-brand-line/5 bg-white p-6 shadow-sm">
                  <div className="text-[10px] font-mono uppercase tracking-[0.24em] text-brand-ink/35">竞品差异</div>
                  <p className="mt-3 text-sm leading-relaxed text-brand-ink/75">{app.teardown?.competitorDelta || '待补充差异化说明。'}</p>
                </div>
              </section>

              <section className="bg-white border border-brand-line/5 rounded-3xl p-8 space-y-6 shadow-sm">
                <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
                  <div>
                    <h2 className="text-2xl font-serif italic">Teardown 模板</h2>
                    <p className="mt-2 text-sm text-brand-ink/50">重点不是复盘 UI，而是复盘这款产品的底层逻辑。</p>
                  </div>
                  {app.teardown ? (
                    <span className="inline-flex rounded-full bg-brand-ink/5 px-3 py-1 text-[11px] font-medium text-brand-ink/55">
                      痛点强度：{app.teardown.painScore}
                    </span>
                  ) : null}
                </div>
                {app.teardown ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {teardownSections.map((section) => (
                      <div key={section.label} className="rounded-2xl border border-brand-line/10 p-5">
                        <div className="flex items-center justify-between gap-4">
                          <div className="text-[10px] font-mono uppercase tracking-[0.24em] text-brand-ink/35">{section.label}</div>
                          {section.meta ? <span className="text-[10px] text-brand-ink/30">{section.meta}</span> : null}
                        </div>
                        <p className="mt-3 text-sm leading-relaxed text-brand-ink/75">{section.value || '待补充'}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-brand-ink/40">拆解内容尚未补齐。</p>
                )}
              </section>

              {app.teardown ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <section className="bg-white border border-brand-line/5 rounded-3xl p-6 space-y-4 shadow-sm">
                    <h3 className="font-bold">关键约束</h3>
                    <div className="flex flex-wrap gap-2">
                      {app.teardown.keyConstraints.map((constraint) => (
                        <span key={constraint} className="rounded-full border border-brand-line/10 bg-brand-ink/5 px-3 py-1 text-xs text-brand-ink/65">
                          {constraint}
                        </span>
                      ))}
                    </div>
                  </section>
                  <section className="bg-white border border-brand-line/5 rounded-3xl p-6 space-y-4 shadow-sm">
                    <h3 className="font-bold">可扩展路线</h3>
                    <div className="space-y-2">
                      {app.teardown.expansionSteps.map((step, index) => (
                        <div key={step} className="flex gap-3 text-sm text-brand-ink/70">
                          <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-brand-ink/5 text-[10px] font-bold">{index + 1}</span>
                          <span>{step}</span>
                        </div>
                      ))}
                    </div>
                  </section>
                  <section className="bg-white border border-brand-line/5 rounded-3xl p-6 space-y-4 shadow-sm md:col-span-2">
                    <h3 className="font-bold">反向拆解</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {app.teardown.reverseIdeas.map((idea) => (
                        <div key={idea} className="rounded-2xl border border-brand-line/10 p-4 text-sm leading-relaxed text-brand-ink/70">
                          {idea}
                        </div>
                      ))}
                    </div>
                  </section>
                </div>
              ) : null}
            </div>
          ) : null}

          {activeTab === '模式' ? (
            <div className="space-y-6">
              <section className="bg-white border border-brand-line/5 rounded-3xl p-8 space-y-6 shadow-sm">
                <h2 className="text-2xl font-serif italic">同模式家族</h2>
                {app.pattern ? (
                  <>
                    <div className="rounded-2xl border border-brand-line/10 p-6">
                      <div className="flex items-center justify-between gap-4">
                        <div>
                          <div className="text-[10px] font-mono uppercase tracking-[0.24em] text-brand-ink/35">Pattern</div>
                          <h3 className="mt-2 text-xl font-bold">{app.pattern.name}</h3>
                        </div>
                        <Link to={`/patterns/${app.pattern.slug}`} className="text-xs font-bold text-brand-ink/60 hover:text-brand-ink">
                          查看模式页
                        </Link>
                      </div>
                      <p className="mt-4 text-sm leading-relaxed text-brand-ink/65">{app.pattern.description}</p>
                    </div>
                    <div className="space-y-3">
                      {app.pattern.relatedApps.map((relatedApp) => (
                        <Link
                          key={relatedApp.slug}
                          to={`/intelligence/${relatedApp.slug}`}
                          className="flex items-center justify-between gap-4 rounded-2xl border border-brand-line/10 bg-white px-5 py-4 transition-colors hover:bg-brand-ink/[0.02]"
                        >
                          <div>
                            <div className="text-sm font-semibold text-brand-ink">{relatedApp.name}</div>
                            <div className="mt-1 text-xs text-brand-ink/35">热度 {relatedApp.heatScore}</div>
                          </div>
                          <ChevronRight className="h-4 w-4 text-brand-ink/30" />
                        </Link>
                      ))}
                    </div>
                  </>
                ) : (
                  <p className="text-sm text-brand-ink/40">当前产品尚未关联模式。</p>
                )}
              </section>
            </div>
          ) : null}

          {activeTab === '讨论' ? (
            <section className="bg-white border border-brand-line/5 rounded-3xl p-8 space-y-6 shadow-sm">
              <div className="flex items-center justify-between gap-4">
                <h2 className="text-2xl font-serif italic">相关讨论</h2>
                <span className="text-xs text-brand-ink/35">{app.discussions.length} 个话题</span>
              </div>
              <div className="space-y-4">
                {app.discussions.length > 0 ? (
                  app.discussions.map((discussion) => (
                    <div key={discussion.id} className="rounded-2xl border border-brand-line/10 p-5">
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <h3 className="text-base font-semibold leading-tight">{discussion.title}</h3>
                          <div className="mt-2 flex items-center gap-3 text-[11px] text-brand-ink/35">
                            <span>{discussion.comments.length} 条评论</span>
                            <span>{discussion.likesCount} 赞</span>
                          </div>
                        </div>
                        <MessageSquare className="h-4 w-4 text-brand-ink/25" />
                      </div>
                      <div className="mt-4 space-y-3">
                        {discussion.comments.slice(0, 3).map((comment) => (
                          <div key={comment.id} className="rounded-2xl bg-brand-ink/[0.02] px-4 py-3 text-sm text-brand-ink/70">
                            <span className="font-semibold text-brand-ink">{comment.authorName}</span>
                            <span className="text-brand-ink/30">：</span>
                            {comment.content}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-brand-ink/40">暂无相关讨论。</p>
                )}
              </div>
            </section>
          ) : null}

          {activeTab === '资产' ? (
            <AssetBundlePanel
              appSlug={app.slug}
              assetEntries={assetEntries}
              activeAssetKey={activeAssetPreview}
              copiedAssetKey={copiedAssetPreview}
              onSelect={setActiveAssetPreview}
              onCopy={() => void handleCopyAsset()}
            />
          ) : null}
        </div>

        <div className="space-y-8">
          <section className="bg-white border border-brand-line/5 rounded-3xl p-6 space-y-4 shadow-sm">
            <h3 className="font-bold flex items-center gap-2"><CheckCircle2 className="h-4 w-4" /> 可信度标签</h3>
            <div className="flex flex-wrap gap-2">
              {app.trustSignals.length > 0 ? (
                app.trustSignals.map((signal) => (
                  <span
                    key={signal}
                    className={cn(
                      'inline-flex items-center rounded-full border px-3 py-1.5 text-xs font-semibold',
                      getTrustSignalClass(signal),
                    )}
                  >
                    {signal}
                  </span>
                ))
              ) : (
                <span className="text-xs text-brand-ink/40">暂无可信度标签</span>
              )}
            </div>
          </section>

          <section className="bg-white border border-brand-line/5 rounded-3xl p-6 space-y-4 shadow-sm">
            <h3 className="font-bold flex items-center gap-2"><Database className="h-4 w-4" /> 关键渠道</h3>
            <div className="flex flex-wrap gap-2">
              {app.channels.map((channel) => (
                <span key={channel} className="px-3 py-1 bg-brand-ink/5 rounded-lg text-xs font-medium text-brand-ink/60">{channel}</span>
              ))}
            </div>
          </section>

          {app.buildAssets ? (
            <section className="bg-white border border-brand-line/5 rounded-3xl p-6 space-y-4 shadow-sm">
              <h3 className="font-bold flex items-center gap-2"><Layers className="h-4 w-4" /> 可建造资产</h3>
              <div className="space-y-3">
                {assetEntries.map((asset) => (
                  <div key={asset.label} className="rounded-2xl border border-brand-line/10 px-4 py-3">
                    <div className="flex items-center justify-between gap-4">
                      <span className="text-sm font-semibold">{asset.label}</span>
                      <span className={cn('text-[10px] font-mono uppercase tracking-[0.22em]', asset.available ? 'text-emerald-600' : 'text-brand-ink/25')}>
                        {asset.available ? 'Ready' : 'Empty'}
                      </span>
                    </div>
                    <p className="mt-2 text-xs leading-relaxed text-brand-ink/45">{asset.desc}</p>
                  </div>
                ))}
              </div>
            </section>
          ) : null}

          <section className="bg-white border border-brand-line/5 rounded-3xl p-6 space-y-4 shadow-sm">
            <h3 className="font-bold flex items-center gap-2"><MessageSquare className="h-4 w-4" /> 相关讨论</h3>
            <div className="space-y-4">
              {app.discussions.map((discussion) => (
                <div key={discussion.id} className="group cursor-pointer space-y-1">
                  <h4 className="text-sm font-medium group-hover:text-brand-ink transition-colors line-clamp-2">{discussion.title}</h4>
                  <div className="flex items-center gap-2 text-[10px] text-brand-ink/40">
                    <span>{discussion.comments.length} 回复</span>
                    <span>•</span>
                    <span>{discussion.likesCount} 赞</span>
                  </div>
                </div>
              ))}
              {app.discussions.length === 0 ? <p className="text-xs text-brand-ink/40">暂无相关讨论</p> : null}
            </div>
          </section>

          <section className="bg-brand-ink text-brand-bg rounded-3xl p-6 space-y-4 shadow-xl">
            <h3 className="font-bold flex items-center gap-2"><TrendingUp className="h-4 w-4" /> 商业模式</h3>
            <div className="p-4 bg-white/10 rounded-2xl space-y-2">
              <div className="text-xs opacity-60 uppercase tracking-widest font-mono">定价</div>
              <div className="text-lg font-bold">{pricingLabelMap[app.pricing] || app.pricing}</div>
            </div>
            <p className="text-xs opacity-60 leading-relaxed">
              {app.teardown?.pricingLogic || app.breakdown.monetization || '待补充商业模式说明。'}
            </p>
            {app.pattern ? (
              <Link to={`/patterns/${app.pattern.slug}`} className="w-full py-3 bg-white text-brand-ink rounded-xl text-xs font-bold hover:bg-opacity-90 transition-all flex items-center justify-center gap-2">
                查看关联模式 <ChevronRight className="h-3 w-3" />
              </Link>
            ) : null}
          </section>
        </div>
      </div>
    </div>
  );
};

const DiscussionsPage = () => {
  const [discussions, setDiscussions] = useState<DiscussionItem[]>([]);
  const [apps, setApps] = useState<AppSummary[]>([]);
  const [patterns, setPatterns] = useState<PatternSummary[]>([]);
  const [search, setSearch] = useState('');
  const [discussionTitle, setDiscussionTitle] = useState('');
  const [discussionTargetType, setDiscussionTargetType] = useState<'APP' | 'PATTERN'>('APP');
  const [discussionTargetId, setDiscussionTargetId] = useState('');
  const [authorName, setAuthorName] = useState('');
  const [content, setContent] = useState('');
  const [likingDiscussionId, setLikingDiscussionId] = useState<string | null>(null);
  const [sharedDiscussionId, setSharedDiscussionId] = useState<string | null>(null);
  const [likedDiscussionIds, setLikedDiscussionIds] = useState<string[]>(() => getLikedDiscussionIds());

  useEffect(() => {
    getDiscussions({ page: 1, pageSize: 20, sort: 'latest' }).then((result) => setDiscussions(result.items)).catch(() => setDiscussions([]));
    getApps({ page: 1, pageSize: 50, sort: 'hot' }).then((result) => setApps(result.items)).catch(() => setApps([]));
    getPatterns().then((result) => setPatterns(result.items)).catch(() => setPatterns([]));
  }, []);

  useEffect(() => {
    const nextTargetId = discussionTargetType === 'APP' ? apps[0]?.id : patterns[0]?.id;
    if (nextTargetId) {
      setDiscussionTargetId((current) => current || nextTargetId);
    }
  }, [discussionTargetType, apps, patterns]);

  const filtered = useMemo(
    () => discussions.filter((item) => item.title.toLowerCase().includes(search.toLowerCase())),
    [discussions, search],
  );

  const discussionStats = useMemo(
    () => [
      { label: '讨论话题', value: `${filtered.length}`, note: '当前筛选结果' },
      { label: '累计评论', value: `${filtered.reduce((sum, item) => sum + item.comments.length, 0)}`, note: '包含引用回复' },
      { label: '应用话题', value: `${filtered.filter((item) => item.targetType === 'APP').length}`, note: '直接关联产品判断' },
    ],
    [filtered],
  );

  const handleQuickReply = async (id: string) => {
    if (!authorName.trim() || !content.trim()) return;
    await createComment(id, { authorName, content });
    const refreshed = await getDiscussion(id);
    setDiscussions((current) => current.map((item) => (item.id === id ? refreshed : item)));
    setContent('');
  };

  const handleCreateDiscussion = async () => {
    if (!discussionTitle.trim() || !discussionTargetId || !authorName.trim() || !content.trim()) return;

    const created = await createDiscussion({
      title: discussionTitle,
      targetType: discussionTargetType,
      targetId: discussionTargetId,
      authorName,
      content,
    });

    setDiscussions((current) => [created, ...current]);
    setDiscussionTitle('');
    setContent('');
  };

  const handleLikeDiscussion = async (id: string) => {
    if (likingDiscussionId || likedDiscussionIds.includes(id)) return;
    setLikingDiscussionId(id);
    try {
      const updated = await likeDiscussion(id);
      setDiscussions((current) => current.map((item) => (item.id === id ? updated : item)));
      setLikedDiscussionIds((current) => {
        const next = current.includes(id) ? current : [...current, id];
        saveLikedDiscussionIds(next);
        return next;
      });
    } finally {
      setLikingDiscussionId(null);
    }
  };

  const handleShareDiscussion = async (id: string) => {
    const shareUrl = `${window.location.origin}/discussions/${id}`;

    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(shareUrl);
    } else {
      const textarea = document.createElement('textarea');
      textarea.value = shareUrl;
      textarea.setAttribute('readonly', 'true');
      textarea.style.position = 'absolute';
      textarea.style.left = '-9999px';
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      textarea.remove();
    }

    setSharedDiscussionId(id);
    window.setTimeout(() => {
      setSharedDiscussionId((current) => (current === id ? null : current));
    }, 1600);
  };

  const targetOptions = discussionTargetType === 'APP' ? apps : patterns;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h1 className="text-4xl font-serif italic">社区讨论</h1>
          <p className="text-brand-ink/50">围绕产品拆解、模式判断与增长动作展开交流</p>
        </div>
        <button
          type="button"
          onClick={() => {
            const form = document.getElementById('discussion-composer');
            form?.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }}
          className="flex items-center gap-2 px-6 py-3 bg-brand-ink text-brand-bg rounded-2xl font-bold hover:opacity-90 transition-opacity whitespace-nowrap"
        >
          <PlusCircle className="h-5 w-5" /> 发起讨论
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {discussionStats.map((item) => (
          <div key={item.label} className="rounded-3xl border border-brand-line/10 bg-white px-6 py-5 shadow-sm">
            <div className="text-[10px] font-mono uppercase tracking-[0.24em] text-brand-ink/35">{item.label}</div>
            <div className="mt-3 text-3xl font-bold tracking-tight">{item.value}</div>
            <div className="mt-1 text-sm text-brand-ink/45">{item.note}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1.6fr)_360px] gap-8">
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-brand-ink/30" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="搜索话题..."
              className="w-full pl-12 pr-4 py-4 bg-white border border-brand-line/10 rounded-2xl focus:outline-none focus:ring-2 focus:ring-brand-ink/5"
            />
          </div>

          <div className="space-y-4">
            {filtered.map((discussion) => {
              const commentsById = new Map(discussion.comments.map((comment) => [comment.id, comment]));
              return (
                <motion.div id={discussion.id} key={discussion.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="p-6 bg-white border border-brand-line/5 rounded-3xl shadow-sm hover:shadow-md transition-all group scroll-mt-28">
                  <div className="flex gap-6">
                    <div className="hidden sm:flex flex-col items-center gap-1 pt-1">
                      <button
                        type="button"
                        onClick={() => void handleLikeDiscussion(discussion.id)}
                        disabled={likingDiscussionId === discussion.id || likedDiscussionIds.includes(discussion.id)}
                        className="p-2 hover:bg-brand-ink/5 rounded-xl transition-colors disabled:cursor-not-allowed disabled:opacity-50"
                        aria-label={likedDiscussionIds.includes(discussion.id) ? '已点赞' : '点赞讨论'}
                      >
                        <Heart className={cn(
                          'h-5 w-5 transition-colors',
                          likingDiscussionId === discussion.id || likedDiscussionIds.includes(discussion.id)
                            ? 'text-red-500'
                            : 'text-brand-ink/30 group-hover:text-red-500',
                        )} />
                      </button>
                      <span className="text-xs font-bold text-brand-ink/40">{discussion.likesCount}</span>
                    </div>
                    <div className="flex-grow space-y-4">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-1 bg-brand-ink/5 rounded text-[10px] font-mono uppercase tracking-widest text-brand-ink/40">{targetTypeMap[discussion.targetType]}</span>
                        <span className="text-[10px] text-brand-ink/30">•</span>
                        <span className="text-[10px] text-brand-ink/30">{new Date(discussion.createdAt).toLocaleDateString('zh-CN')}</span>
                      </div>
                      <h3 className="text-xl font-bold leading-tight transition-colors">
                        <Link to={`/discussions/${discussion.id}`} className="group-hover:text-brand-ink hover:text-brand-ink">
                          {discussion.title}
                        </Link>
                      </h3>
                      <div className="space-y-3">
                        {discussion.comments.slice(0, 3).map((comment) => {
                          const replyTo = comment.replyToCommentId ? commentsById.get(comment.replyToCommentId) : null;
                          return (
                            <div key={comment.id} className="rounded-2xl bg-brand-ink/[0.02] px-4 py-3">
                              {replyTo ? (
                                <div className="mb-2 rounded-xl border-l-2 border-brand-line/20 bg-white/70 px-3 py-2 text-xs text-brand-ink/45">
                                  引用 {replyTo.authorName}：{replyTo.content}
                                </div>
                              ) : null}
                              <div className="text-sm text-brand-ink/60">
                                <span className="font-bold text-brand-ink/80">{comment.authorName}</span>：{comment.content}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-6 text-brand-ink/30">
                          <div className="flex items-center gap-1.5">
                            <MessageSquare className="h-4 w-4" />
                            <span className="text-xs font-bold">{discussion.comments.length}</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => void handleShareDiscussion(discussion.id)}
                            className={cn(
                              'inline-flex items-center gap-1.5 transition-colors',
                              sharedDiscussionId === discussion.id ? 'text-brand-ink' : 'hover:text-brand-ink',
                            )}
                            aria-label="分享讨论"
                          >
                            <Share2 className="h-4 w-4" />
                            <span className="text-xs font-bold">{sharedDiscussionId === discussion.id ? '已复制' : '分享'}</span>
                          </button>
                        </div>
                        <div className="flex items-center gap-4">
                          <Link to={`/discussions/${discussion.id}`} className="text-xs font-bold text-brand-ink/35 hover:text-brand-ink/60">
                            查看详情
                          </Link>
                          <button onClick={() => void handleQuickReply(discussion.id)} className="text-xs font-bold text-brand-ink/60 hover:text-brand-ink">
                            快速回复
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        <aside className="space-y-6">
          <section id="discussion-composer" className="rounded-3xl border border-brand-line/10 bg-white p-6 shadow-sm space-y-4 xl:sticky xl:top-28">
            <div className="space-y-2">
              <h2 className="text-2xl font-serif italic">快速参与</h2>
              <p className="text-sm leading-relaxed text-brand-ink/50">讨论是扁平流结构，回复会用引用条标记上下文，不做树状嵌套。</p>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-widest text-brand-ink/40">讨论标题</label>
              <input
                type="text"
                value={discussionTitle}
                onChange={(e) => setDiscussionTitle(e.target.value)}
                placeholder="例如：这个产品的冷启动还能怎么优化？"
                className="w-full px-4 py-4 bg-brand-ink/5 border-none rounded-2xl focus:ring-2 focus:ring-brand-ink/10 outline-none"
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-brand-ink/40">目标类型</label>
                <select
                  value={discussionTargetType}
                  onChange={(e) => {
                    const nextType = e.target.value as 'APP' | 'PATTERN';
                    setDiscussionTargetType(nextType);
                    setDiscussionTargetId(nextType === 'APP' ? apps[0]?.id || '' : patterns[0]?.id || '');
                  }}
                  className="w-full px-4 py-4 bg-brand-ink/5 border-none rounded-2xl focus:ring-2 focus:ring-brand-ink/10 outline-none appearance-none"
                >
                  <option value="APP">应用</option>
                  <option value="PATTERN">模式</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-brand-ink/40">讨论对象</label>
                <select
                  value={discussionTargetId}
                  onChange={(e) => setDiscussionTargetId(e.target.value)}
                  className="w-full px-4 py-4 bg-brand-ink/5 border-none rounded-2xl focus:ring-2 focus:ring-brand-ink/10 outline-none appearance-none"
                >
                  {targetOptions.map((target) => (
                    <option key={target.id} value={target.id}>{target.name}</option>
                  ))}
                </select>
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-widest text-brand-ink/40">你的昵称</label>
              <input
                type="text"
                value={authorName}
                onChange={(e) => setAuthorName(e.target.value)}
                placeholder="例如：增长研究员"
                className="w-full px-4 py-4 bg-brand-ink/5 border-none rounded-2xl focus:ring-2 focus:ring-brand-ink/10 outline-none"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-widest text-brand-ink/40">评论内容</label>
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="输入评论内容，点击左侧每条卡片底部即可快速回复..."
                className="w-full p-4 bg-brand-ink/5 border-none rounded-2xl focus:ring-2 focus:ring-brand-ink/10 outline-none min-h-36 resize-none"
              />
            </div>
            <div className="rounded-2xl border border-brand-line/10 bg-brand-ink/[0.02] px-4 py-3 text-xs leading-relaxed text-brand-ink/45">
              建议先写判断，再写依据。高质量讨论优先围绕用户场景、定价逻辑和冷启动可行性。
            </div>
            <button
              type="button"
              onClick={() => void handleCreateDiscussion()}
              disabled={!discussionTitle.trim() || !discussionTargetId || !authorName.trim() || !content.trim()}
              className="w-full inline-flex items-center justify-center gap-2 rounded-2xl bg-brand-ink px-4 py-4 text-sm font-bold text-brand-bg transition-opacity hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-30"
            >
              <PlusCircle className="h-4 w-4" />
              发布讨论
            </button>
          </section>
        </aside>
      </div>
    </div>
  );
};

const DiscussionDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [discussion, setDiscussion] = useState<DiscussionItem | null>(null);
  const [authorName, setAuthorName] = useState('');
  const [content, setContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLiking, setIsLiking] = useState(false);
  const [isSharing, setIsSharing] = useState(false);
  const [likedDiscussionIds, setLikedDiscussionIds] = useState<string[]>(() => getLikedDiscussionIds());

  useEffect(() => {
    if (!id) {
      setDiscussion(null);
      return;
    }

    getDiscussion(id)
      .then((result) => setDiscussion(result))
      .catch(() => setDiscussion(null));
  }, [id]);

  const handleReply = async () => {
    if (!discussion || !authorName.trim() || !content.trim()) return;
    setIsSubmitting(true);
    try {
      await createComment(discussion.id, { authorName, content });
      const refreshed = await getDiscussion(discussion.id);
      setDiscussion(refreshed);
      setContent('');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLike = async () => {
    if (!discussion || isLiking || likedDiscussionIds.includes(discussion.id)) return;
    setIsLiking(true);
    try {
      const updated = await likeDiscussion(discussion.id);
      setDiscussion(updated);
      setLikedDiscussionIds((current) => {
        const next = current.includes(discussion.id) ? current : [...current, discussion.id];
        saveLikedDiscussionIds(next);
        return next;
      });
    } finally {
      setIsLiking(false);
    }
  };

  const handleShare = async () => {
    if (!discussion) return;
    const shareUrl = `${window.location.origin}/discussions/${discussion.id}`;
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(shareUrl);
    } else {
      const textarea = document.createElement('textarea');
      textarea.value = shareUrl;
      textarea.setAttribute('readonly', 'true');
      textarea.style.position = 'absolute';
      textarea.style.left = '-9999px';
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      textarea.remove();
    }

    setIsSharing(true);
    window.setTimeout(() => setIsSharing(false), 1600);
  };

  if (!discussion) {
    return (
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="rounded-3xl border border-brand-line/10 bg-white p-8 shadow-sm space-y-4">
          <button type="button" onClick={() => navigate('/discussions')} className="text-xs font-bold text-brand-ink/45 hover:text-brand-ink/70">
            返回讨论列表
          </button>
          <h1 className="text-3xl font-serif italic">讨论不存在</h1>
          <p className="text-sm text-brand-ink/50">这个讨论可能已被删除，或者链接有误。</p>
        </div>
      </div>
    );
  }

  const commentsById = new Map(discussion.comments.map((comment) => [comment.id, comment]));

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
      <div className="flex flex-col gap-4">
        <button type="button" onClick={() => navigate('/discussions')} className="w-fit text-xs font-bold text-brand-ink/45 hover:text-brand-ink/70">
          返回讨论列表
        </button>
        <div className="rounded-3xl border border-brand-line/10 bg-white p-8 shadow-sm space-y-5">
          <div className="flex flex-wrap items-center gap-3 text-[10px] font-mono uppercase tracking-[0.24em] text-brand-ink/35">
            <span className="rounded-full bg-brand-ink/5 px-3 py-1 text-brand-ink/45">{targetTypeMap[discussion.targetType]}</span>
            <span>{new Date(discussion.createdAt).toLocaleDateString('zh-CN')}</span>
          </div>
          <h1 className="text-4xl font-serif italic leading-tight">{discussion.title}</h1>
          <div className="flex flex-wrap items-center gap-3 text-sm text-brand-ink/45">
            <button
              type="button"
              onClick={() => void handleLike()}
              disabled={isLiking || likedDiscussionIds.includes(discussion.id)}
              className="inline-flex min-h-11 items-center gap-2 rounded-2xl border border-brand-line/10 px-4 py-2 font-semibold text-brand-ink/60 transition-colors hover:bg-brand-ink/5 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <Heart className={cn('h-4 w-4', isLiking || likedDiscussionIds.includes(discussion.id) ? 'text-red-500' : 'text-brand-ink/35')} />
              {likedDiscussionIds.includes(discussion.id) ? '已点赞' : `${discussion.likesCount} 赞`}
            </button>
            <button
              type="button"
              onClick={() => void handleShare()}
              className="inline-flex min-h-11 items-center gap-2 rounded-2xl border border-brand-line/10 px-4 py-2 font-semibold text-brand-ink/60 transition-colors hover:bg-brand-ink/5"
            >
              <Share2 className="h-4 w-4" />
              {isSharing ? '链接已复制' : '复制分享链接'}
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1.6fr)_360px] gap-8">
        <section className="rounded-3xl border border-brand-line/10 bg-white p-8 shadow-sm space-y-5">
          <div className="flex items-center justify-between gap-4">
            <h2 className="text-2xl font-serif italic">全部评论</h2>
            <span className="text-xs font-bold text-brand-ink/35">{discussion.comments.length} 条</span>
          </div>
          <div className="space-y-4">
            {discussion.comments.map((comment) => {
              const replyTo = comment.replyToCommentId ? commentsById.get(comment.replyToCommentId) : null;
              return (
                <div key={comment.id} className="rounded-3xl border border-brand-line/10 bg-brand-ink/[0.02] px-5 py-4">
                  {replyTo ? (
                    <div className="mb-3 rounded-2xl border-l-2 border-brand-line/20 bg-white px-4 py-3 text-xs leading-6 text-brand-ink/45">
                      引用 {replyTo.authorName}：{replyTo.content}
                    </div>
                  ) : null}
                  <div className="flex items-start justify-between gap-4">
                    <div className="text-sm leading-7 text-brand-ink/65">
                      <span className="font-bold text-brand-ink/80">{comment.authorName}</span>：{comment.content}
                    </div>
                    <span className="shrink-0 text-[11px] text-brand-ink/30">
                      {new Date(comment.createdAt).toLocaleDateString('zh-CN')}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        <aside className="rounded-3xl border border-brand-line/10 bg-white p-6 shadow-sm space-y-4 xl:sticky xl:top-28 h-fit">
          <div className="space-y-2">
            <h2 className="text-2xl font-serif italic">参与回复</h2>
            <p className="text-sm leading-relaxed text-brand-ink/50">延续当前线程，保持扁平流，不做树状嵌套。</p>
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-widest text-brand-ink/40">你的昵称</label>
            <input
              type="text"
              value={authorName}
              onChange={(e) => setAuthorName(e.target.value)}
              placeholder="例如：增长产品经理"
              className="w-full px-4 py-4 bg-brand-ink/5 border-none rounded-2xl focus:ring-2 focus:ring-brand-ink/10 outline-none"
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-widest text-brand-ink/40">回复内容</label>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              rows={6}
              placeholder="补充你的判断、依据或实践经验。"
              className="w-full px-4 py-4 bg-brand-ink/5 border-none rounded-2xl focus:ring-2 focus:ring-brand-ink/10 outline-none resize-none"
            />
          </div>
          <button
            type="button"
            onClick={() => void handleReply()}
            disabled={isSubmitting || !authorName.trim() || !content.trim()}
            className="w-full min-h-11 rounded-2xl bg-brand-ink px-4 py-3 text-sm font-bold text-brand-bg transition-opacity hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {isSubmitting ? '提交中...' : '发布回复'}
          </button>
        </aside>
      </div>
    </div>
  );
};

const PatternsPage = () => {
  const [patterns, setPatterns] = useState<PatternSummary[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('全部');
  const categories = ['全部', '高频工作流'];

  useEffect(() => {
    getPatterns().then((result) => setPatterns(result.items)).catch(() => setPatterns([]));
  }, []);

  const filteredPatterns = patterns.filter(() => selectedCategory === '全部' || selectedCategory === '高频工作流');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      <div className="text-center space-y-4">
        <h1 className="text-5xl font-serif italic">模式库</h1>
        <p className="text-brand-ink/50 max-w-2xl mx-auto">按模式拆解不同产品共用的商业机制与交互策略，为你的下一步判断提供参考。</p>
      </div>

      <div className="flex flex-wrap justify-center gap-2">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={cn(
              'px-6 py-2 rounded-full text-sm font-medium transition-all',
              selectedCategory === cat ? 'bg-brand-ink text-brand-bg shadow-lg shadow-brand-ink/20' : 'bg-white border border-brand-line/10 text-brand-ink/60 hover:border-brand-ink/30',
            )}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="columns-1 md:columns-2 lg:columns-3 gap-6 space-y-6">
        {filteredPatterns.map((pattern) => (
          <motion.div layout key={pattern.id} initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="break-inside-avoid group relative bg-white border border-brand-line/5 rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500">
            <div className="relative aspect-[4/3] bg-brand-ink/5">
              <div className="absolute inset-0 bg-gradient-to-br from-brand-ink/5 to-brand-ink/15" />
              <div className="absolute inset-0 p-6 flex flex-col justify-between">
                <span className="text-[10px] font-mono uppercase tracking-widest text-brand-ink/40 bg-white/80 px-2 py-1 rounded w-fit">模式</span>
                <div className="w-14 h-14 rounded-2xl bg-white flex items-center justify-center shadow-sm text-2xl font-bold">{pattern.name.slice(0, 1)}</div>
              </div>
            </div>
            <div className="p-6 space-y-3">
              <div className="flex justify-between items-start gap-4">
                <span className="text-[10px] font-mono uppercase tracking-widest text-brand-ink/40 bg-brand-ink/5 px-2 py-1 rounded">{pattern.appCount} 个产品</span>
                <Link to={`/patterns/${pattern.slug}`} className="text-xs font-bold text-brand-ink/60 hover:text-brand-ink">查看详情</Link>
              </div>
              <h3 className="text-lg font-bold leading-tight">{pattern.name}</h3>
              <p className="text-sm text-brand-ink/50 line-clamp-3 leading-relaxed">{pattern.description}</p>
              <div className="pt-4 border-t border-brand-line/5 flex justify-between items-center text-brand-ink/30">
                <span className="flex items-center gap-1 text-xs"><Heart className="h-3 w-3" /> {pattern.appCount * 18}</span>
                <span className="flex items-center gap-1 text-xs"><MessageCircle className="h-3 w-3" /> {pattern.appCount * 3}</span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

const PatternDetailPage = () => {
  const { slug } = useParams();
  const [detail, setDetail] = useState<PatternDetail | null>(null);
  useEffect(() => {
    if (!slug) return;
    getPatternDetail(slug).then(setDetail).catch(() => setDetail(null));
  }, [slug]);

  if (!detail) return <div className="p-20 text-center">未找到该模式。</div>;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
      <div className="space-y-3">
        <Link to="/patterns" className="text-sm font-bold text-brand-ink/40 hover:text-brand-ink">返回模式库</Link>
        <h1 className="text-4xl font-serif italic">{detail.name}</h1>
        <p className="text-brand-ink/50 max-w-3xl">{detail.description}</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white border border-brand-line/5 rounded-3xl p-8 shadow-sm space-y-4">
          <h2 className="text-2xl font-serif italic">适用场景</h2>
          <div className="flex flex-wrap gap-2">
            {detail.useCases.map((useCase) => (
              <span key={useCase} className="px-3 py-1 bg-brand-ink/5 rounded-lg text-xs font-medium text-brand-ink/60">{useCase}</span>
            ))}
          </div>
        </div>
        <div className="bg-white border border-brand-line/5 rounded-3xl p-8 shadow-sm space-y-4">
          <h2 className="text-2xl font-serif italic">已验证产品</h2>
          <div className="space-y-3">
            {detail.apps.map((app) => (
              <Link key={app.slug} to={`/intelligence/${app.slug}`} className="flex items-center justify-between p-4 bg-brand-ink/5 rounded-2xl hover:bg-brand-ink/8 transition-colors">
                <span>{app.name}</span>
                <span className="text-sm text-brand-ink/50">{pricingLabelMap[app.pricing] || app.pricing}</span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const SubmitPage = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [patterns, setPatterns] = useState<PatternSummary[]>([]);
  const [done, setDone] = useState(false);
  const [uploadingScreenshot, setUploadingScreenshot] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<string>('');
  const [formData, setFormData] = useState<SubmissionPayload>({
    productName: '',
    websiteUrl: '',
    selectedPattern: '',
    notes: '',
    contactEmail: '',
    screenshotUrl: '',
  });

  useEffect(() => {
    getPatterns().then((result) => setPatterns(result.items)).catch(() => setPatterns([]));
  }, []);

  const nextStep = () => setStep((s) => s + 1);
  const prevStep = () => setStep((s) => s - 1);

  const handleScreenshotUpload = async (file?: File | null) => {
    if (!file) return;
    setUploadingScreenshot(true);
    setUploadStatus('');
    try {
      const uploaded = await uploadScreenshot(file);
      setFormData((current) => ({ ...current, screenshotUrl: uploaded.absoluteUrl }));
      setUploadStatus(`已上传并压缩到 ${(uploaded.sizeBytes / 1024).toFixed(1)}KB`);
    } catch (error) {
      setUploadStatus(error instanceof Error ? error.message : '截图上传失败');
    } finally {
      setUploadingScreenshot(false);
    }
  };

  const submitAll = async () => {
    await createSubmission(formData);
    setDone(true);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-20">
      <div className="space-y-12">
        <div className="flex justify-between items-center relative">
          <div className="absolute left-0 top-1/2 -translate-y-1/2 w-full h-0.5 bg-brand-ink/5 z-0" />
          <div className="absolute left-0 top-1/2 -translate-y-1/2 h-0.5 bg-brand-ink transition-all duration-500 z-0" style={{ width: `${done ? 100 : ((step - 1) / 2) * 100}%` }} />
          {[1, 2, 3].map((i) => (
            <div key={i} className={cn('w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-all duration-500 z-10 border-4', step >= i || done ? 'bg-brand-ink text-brand-bg border-brand-ink' : 'bg-white text-brand-ink/20 border-brand-ink/5')}>
              {step > i || done ? <CheckCircle2 className="h-5 w-5" /> : i}
            </div>
          ))}
        </div>

        <div className="bg-white border border-brand-line/5 rounded-3xl p-8 md:p-12 shadow-xl">
          <AnimatePresence mode="wait">
            {!done && step === 1 && (
              <motion.div key="step1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-8">
                <div className="space-y-2">
                  <h2 className="text-3xl font-serif italic">基本信息</h2>
                  <p className="text-brand-ink/50">告诉我们你想提交的产品和官网地址。</p>
                </div>
                <div className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest text-brand-ink/40">产品名称</label>
                    <input type="text" placeholder="例如：播客切片工坊" className="w-full p-4 bg-brand-ink/5 border-none rounded-2xl focus:ring-2 focus:ring-brand-ink/10 outline-none" value={formData.productName} onChange={(e) => setFormData({ ...formData, productName: e.target.value })} />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest text-brand-ink/40">官方网址</label>
                    <div className="relative">
                      <Globe className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-brand-ink/20" />
                      <input type="url" placeholder="https://example.com" className="w-full p-4 pl-12 bg-brand-ink/5 border-none rounded-2xl focus:ring-2 focus:ring-brand-ink/10 outline-none" value={formData.websiteUrl} onChange={(e) => setFormData({ ...formData, websiteUrl: e.target.value })} />
                    </div>
                  </div>
                </div>
                <button onClick={nextStep} disabled={!formData.productName || !formData.websiteUrl} className="w-full py-4 bg-brand-ink text-brand-bg rounded-2xl font-bold flex items-center justify-center gap-2 hover:opacity-90 transition-opacity disabled:opacity-30">下一步 <ArrowRight className="h-5 w-5" /></button>
              </motion.div>
            )}

            {!done && step === 2 && (
              <motion.div key="step2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-8">
                <div className="space-y-2">
                  <h2 className="text-3xl font-serif italic">分类与补充</h2>
                  <p className="text-brand-ink/50">补充所属模式、联系邮箱和一句话描述。</p>
                </div>
                <div className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest text-brand-ink/40">关联模式</label>
                    <select className="w-full p-4 bg-brand-ink/5 border-none rounded-2xl focus:ring-2 focus:ring-brand-ink/10 outline-none appearance-none" value={formData.selectedPattern} onChange={(e) => setFormData({ ...formData, selectedPattern: e.target.value })}>
                      <option value="">选择模式</option>
                      {patterns.map((pattern) => <option key={pattern.id} value={pattern.slug}>{pattern.name}</option>)}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest text-brand-ink/40">联系邮箱</label>
                    <input type="email" placeholder="you@example.com" className="w-full p-4 bg-brand-ink/5 border-none rounded-2xl focus:ring-2 focus:ring-brand-ink/10 outline-none" value={formData.contactEmail} onChange={(e) => setFormData({ ...formData, contactEmail: e.target.value })} />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest text-brand-ink/40">一句话描述</label>
                    <textarea placeholder="简短介绍该产品的核心价值..." className="w-full p-4 bg-brand-ink/5 border-none rounded-2xl focus:ring-2 focus:ring-brand-ink/10 outline-none h-32 resize-none" value={formData.notes} onChange={(e) => setFormData({ ...formData, notes: e.target.value })} />
                  </div>
                  <div className="space-y-3">
                    <label className="text-xs font-bold uppercase tracking-widest text-brand-ink/40">产品截图</label>
                    <label className="block rounded-2xl border border-dashed border-brand-line/20 bg-brand-ink/[0.02] px-4 py-5 cursor-pointer hover:bg-brand-ink/[0.03] transition-colors">
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => void handleScreenshotUpload(e.target.files?.[0])}
                      />
                      <div className="text-sm font-semibold text-brand-ink/65">
                        {uploadingScreenshot ? '截图上传中...' : '选择截图并上传（自动压缩到 100KB 内）'}
                      </div>
                      <div className="mt-1 text-xs text-brand-ink/40">文件会保存到当前 ECS 服务器本地目录。</div>
                    </label>
                    {formData.screenshotUrl ? (
                      <a href={formData.screenshotUrl} target="_blank" rel="noreferrer" className="inline-flex text-xs font-bold text-brand-ink/55 hover:text-brand-ink">
                        查看已上传截图
                      </a>
                    ) : null}
                    {uploadStatus ? <div className="text-xs text-brand-ink/45">{uploadStatus}</div> : null}
                  </div>
                </div>
                <div className="flex gap-4">
                  <button onClick={prevStep} className="flex-1 py-4 bg-brand-ink/5 text-brand-ink rounded-2xl font-bold hover:bg-brand-ink/10 transition-colors">返回</button>
                  <button onClick={nextStep} disabled={!formData.contactEmail} className="flex-[2] py-4 bg-brand-ink text-brand-bg rounded-2xl font-bold flex items-center justify-center gap-2 hover:opacity-90 transition-opacity disabled:opacity-30">下一步 <ArrowRight className="h-5 w-5" /></button>
                </div>
              </motion.div>
            )}

            {!done && step === 3 && (
              <motion.div key="step3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-8">
                <div className="space-y-2">
                  <h2 className="text-3xl font-serif italic">确认提交</h2>
                  <p className="text-brand-ink/50">最后确认信息，提交后会进入后台审核与人工录入流程。</p>
                </div>
                <div className="p-6 bg-brand-ink/5 rounded-3xl space-y-3 text-sm text-brand-ink/70">
                  <div><span className="font-bold text-brand-ink">产品：</span>{formData.productName}</div>
                  <div><span className="font-bold text-brand-ink">网址：</span>{formData.websiteUrl}</div>
                  <div><span className="font-bold text-brand-ink">邮箱：</span>{formData.contactEmail}</div>
                  <div><span className="font-bold text-brand-ink">截图：</span>{formData.screenshotUrl ? '已上传' : '未上传'}</div>
                </div>
                <div className="flex gap-4">
                  <button onClick={prevStep} className="flex-1 py-4 bg-brand-ink/5 text-brand-ink rounded-2xl font-bold hover:bg-brand-ink/10 transition-colors">返回</button>
                  <button onClick={() => void submitAll()} className="flex-[2] py-4 bg-brand-ink text-brand-bg rounded-2xl font-bold hover:opacity-90 transition-opacity">提交产品</button>
                </div>
              </motion.div>
            )}

            {done && (
              <motion.div key="done" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="text-center space-y-8 py-8">
                <div className="w-20 h-20 bg-green-500 text-white rounded-full flex items-center justify-center mx-auto shadow-xl shadow-green-500/20"><CheckCircle2 className="h-10 w-10" /></div>
                <div className="space-y-2">
                  <h2 className="text-3xl font-serif italic">提交成功</h2>
                  <p className="text-brand-ink/50">我们会在审核后把它放进产品库，并继续补全拆解内容。</p>
                </div>
                <div className="p-6 bg-brand-ink/5 rounded-3xl text-left space-y-4">
                  <div className="flex items-start gap-3">
                    <Info className="h-5 w-5 text-brand-ink/30 mt-0.5" />
                    <p className="text-xs text-brand-ink/60 leading-relaxed">当前版本不支持邮件通知，审核与录入将由后台人工完成。</p>
                  </div>
                </div>
                <button onClick={() => navigate('/')} className="w-full py-4 bg-brand-ink text-brand-bg rounded-2xl font-bold hover:opacity-90 transition-opacity">返回首页</button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

const AdminPage = () => {
  const [activeTab, setActiveTab] = useState<'apps' | 'patterns' | 'discussions' | 'submissions' | 'subscribers'>('apps');
  const [apps, setApps] = useState<AdminAppRecord[]>([]);
  const [patterns, setPatterns] = useState<AdminPatternRecord[]>([]);
  const [discussions, setDiscussions] = useState<DiscussionItem[]>([]);
  const [submissions, setSubmissions] = useState<SubmissionRecord[]>([]);
  const [subscribers, setSubscribers] = useState<SubscriberRecord[]>([]);
  const [busyKey, setBusyKey] = useState<string | null>(null);
  const [adminNotice, setAdminNotice] = useState('');

  const [appDraft, setAppDraft] = useState({
    id: '',
    slug: '',
    name: '',
    tagline: '',
    saveTimeLabel: '',
    category: '效率',
    pricing: 'FREEMIUM',
    channelsText: '',
    targetPersona: '',
    hookAngle: '',
    trustSignalsText: '',
    difficulty: '1',
    heatScore: '0',
    screenshotUrlsText: '',
    patternId: '',
    teardownJson: '',
    assetBundleJson: '',
  });

  const [patternDraft, setPatternDraft] = useState({
    id: '',
    slug: '',
    name: '',
    description: '',
    useCasesText: '',
  });

  const [subscriberDraft, setSubscriberDraft] = useState({
    id: '',
    email: '',
  });

  const resetAppDraft = () => {
    setAppDraft({
      id: '',
      slug: '',
      name: '',
      tagline: '',
      saveTimeLabel: '',
      category: '效率',
      pricing: 'FREEMIUM',
      channelsText: '',
      targetPersona: '',
      hookAngle: '',
      trustSignalsText: '',
      difficulty: '1',
      heatScore: '0',
      screenshotUrlsText: '',
      patternId: '',
      teardownJson: '',
      assetBundleJson: '',
    });
  };

  const resetPatternDraft = () => {
    setPatternDraft({
      id: '',
      slug: '',
      name: '',
      description: '',
      useCasesText: '',
    });
  };

  const resetSubscriberDraft = () => {
    setSubscriberDraft({
      id: '',
      email: '',
    });
  };

  const loadAdminData = async () => {
    const [appItems, patternItems, discussionItems, submissionItems, subscriberItems] = await Promise.all([
      getAdminApps(),
      getAdminPatterns(),
      getAdminDiscussions(),
      getAdminSubmissions(),
      getAdminSubscribers(),
    ]);

    setApps(appItems);
    setPatterns(patternItems);
    setDiscussions(discussionItems);
    setSubmissions(submissionItems);
    setSubscribers(subscriberItems);
  };

  useEffect(() => {
    void loadAdminData().catch(() => setAdminNotice('后台数据加载失败，请检查 API 是否运行。'));
  }, []);

  const linesToArray = (value: string) => value.split('\n').map((item) => item.trim()).filter(Boolean);

  const parseJsonTextarea = (value: string, field: string) => {
    if (!value.trim()) return undefined;
    try {
      return JSON.parse(value) as Record<string, unknown>;
    } catch {
      throw new Error(`${field} 需要是合法 JSON`);
    }
  };

  const selectApp = (item: AdminAppRecord) => {
    setAppDraft({
      id: item.id,
      slug: item.slug,
      name: item.name,
      tagline: item.tagline || '',
      saveTimeLabel: item.saveTimeLabel,
      category: item.category,
      pricing: item.pricing,
      channelsText: item.channels.join('\n'),
      targetPersona: item.targetPersona,
      hookAngle: item.hookAngle,
      trustSignalsText: item.trustSignals.join('\n'),
      difficulty: String(item.difficulty),
      heatScore: String(item.heatScore),
      screenshotUrlsText: item.screenshotUrls.join('\n'),
      patternId: item.patternId || '',
      teardownJson: item.teardown ? JSON.stringify(item.teardown, null, 2) : '',
      assetBundleJson: item.assetBundle ? JSON.stringify(item.assetBundle, null, 2) : '',
    });
    setActiveTab('apps');
  };

  const selectPattern = (item: AdminPatternRecord) => {
    setPatternDraft({
      id: item.id,
      slug: item.slug,
      name: item.name,
      description: item.description,
      useCasesText: item.useCases.join('\n'),
    });
    setActiveTab('patterns');
  };

  const saveApp = async () => {
    setBusyKey('save-app');
    setAdminNotice('');
    try {
      const payload: Record<string, unknown> = {
        slug: appDraft.slug,
        name: appDraft.name,
        tagline: appDraft.tagline,
        saveTimeLabel: appDraft.saveTimeLabel,
        category: appDraft.category,
        pricing: appDraft.pricing,
        channels: linesToArray(appDraft.channelsText),
        targetPersona: appDraft.targetPersona,
        hookAngle: appDraft.hookAngle,
        trustSignals: linesToArray(appDraft.trustSignalsText),
        difficulty: Number(appDraft.difficulty),
        heatScore: Number(appDraft.heatScore),
        screenshotUrls: linesToArray(appDraft.screenshotUrlsText),
        patternId: appDraft.patternId || null,
      };

      const teardown = parseJsonTextarea(appDraft.teardownJson, 'Teardown JSON');
      const assetBundle = parseJsonTextarea(appDraft.assetBundleJson, '资产 JSON');
      if (teardown) payload.teardown = teardown;
      if (assetBundle) payload.assetBundle = assetBundle;

      if (appDraft.id) {
        await updateAdminApp(appDraft.id, payload);
        setAdminNotice('产品已更新。');
      } else {
        await createAdminApp(payload);
        setAdminNotice('产品已创建。');
      }
      await loadAdminData();
      resetAppDraft();
    } catch (error) {
      setAdminNotice(error instanceof Error ? error.message : '保存产品失败');
    } finally {
      setBusyKey(null);
    }
  };

  const removeApp = async (id: string) => {
    setBusyKey(`delete-app-${id}`);
    setAdminNotice('');
    try {
      await deleteAdminApp(id);
      await loadAdminData();
      if (appDraft.id === id) resetAppDraft();
      setAdminNotice('产品已删除。');
    } catch (error) {
      setAdminNotice(error instanceof Error ? error.message : '删除产品失败');
    } finally {
      setBusyKey(null);
    }
  };

  const savePattern = async () => {
    setBusyKey('save-pattern');
    setAdminNotice('');
    try {
      const payload = {
        slug: patternDraft.slug,
        name: patternDraft.name,
        description: patternDraft.description,
        useCases: linesToArray(patternDraft.useCasesText),
      };
      if (patternDraft.id) {
        await updateAdminPattern(patternDraft.id, payload);
        setAdminNotice('模式已更新。');
      } else {
        await createAdminPattern(payload);
        setAdminNotice('模式已创建。');
      }
      await loadAdminData();
      resetPatternDraft();
    } catch (error) {
      setAdminNotice(error instanceof Error ? error.message : '保存模式失败');
    } finally {
      setBusyKey(null);
    }
  };

  const removePattern = async (id: string) => {
    setBusyKey(`delete-pattern-${id}`);
    setAdminNotice('');
    try {
      await deleteAdminPattern(id);
      await loadAdminData();
      if (patternDraft.id === id) resetPatternDraft();
      setAdminNotice('模式已删除。');
    } catch (error) {
      setAdminNotice(error instanceof Error ? error.message : '删除模式失败');
    } finally {
      setBusyKey(null);
    }
  };

  const saveSubscriber = async () => {
    setBusyKey('save-subscriber');
    setAdminNotice('');
    try {
      if (subscriberDraft.id) {
        await updateAdminSubscriber(subscriberDraft.id, subscriberDraft.email);
        setAdminNotice('订阅者已更新。');
      } else {
        await createAdminSubscriber(subscriberDraft.email);
        setAdminNotice('订阅者已创建。');
      }
      await loadAdminData();
      resetSubscriberDraft();
    } catch (error) {
      setAdminNotice(error instanceof Error ? error.message : '保存订阅者失败');
    } finally {
      setBusyKey(null);
    }
  };

  const removeSubscriber = async (id: string) => {
    setBusyKey(`delete-subscriber-${id}`);
    setAdminNotice('');
    try {
      await deleteAdminSubscriber(id);
      await loadAdminData();
      if (subscriberDraft.id === id) resetSubscriberDraft();
      setAdminNotice('订阅者已删除。');
    } catch (error) {
      setAdminNotice(error instanceof Error ? error.message : '删除订阅者失败');
    } finally {
      setBusyKey(null);
    }
  };

  const moderateSubmission = async (id: string, status: 'APPROVED' | 'REJECTED') => {
    setBusyKey(`review-${id}`);
    setAdminNotice('');
    try {
      await reviewSubmission(id, { status });
      await loadAdminData();
      setAdminNotice(`提交已${status === 'APPROVED' ? '通过' : '拒绝'}。`);
    } catch (error) {
      setAdminNotice(error instanceof Error ? error.message : '审核失败');
    } finally {
      setBusyKey(null);
    }
  };

  const removeSubmission = async (id: string) => {
    setBusyKey(`delete-submission-${id}`);
    setAdminNotice('');
    try {
      await deleteSubmission(id);
      await loadAdminData();
      setAdminNotice('提交已删除。');
    } catch (error) {
      setAdminNotice(error instanceof Error ? error.message : '删除提交失败');
    } finally {
      setBusyKey(null);
    }
  };

  const saveDiscussionTitle = async (id: string, title: string) => {
    setBusyKey(`discussion-${id}`);
    setAdminNotice('');
    try {
      await updateAdminDiscussion(id, { title });
      await loadAdminData();
      setAdminNotice('讨论标题已更新。');
    } catch (error) {
      setAdminNotice(error instanceof Error ? error.message : '更新讨论失败');
    } finally {
      setBusyKey(null);
    }
  };

  const removeDiscussion = async (id: string) => {
    setBusyKey(`delete-discussion-${id}`);
    setAdminNotice('');
    try {
      await deleteAdminDiscussion(id);
      await loadAdminData();
      setAdminNotice('讨论已删除。');
    } catch (error) {
      setAdminNotice(error instanceof Error ? error.message : '删除讨论失败');
    } finally {
      setBusyKey(null);
    }
  };

  const uploadAdminScreenshot = async (file?: File | null) => {
    if (!file) return;
    setBusyKey('upload-app-screenshot');
    setAdminNotice('');
    try {
      const uploaded = await uploadScreenshot(file);
      setAppDraft((current) => ({
        ...current,
        screenshotUrlsText: [current.screenshotUrlsText, uploaded.absoluteUrl].filter(Boolean).join('\n'),
      }));
      setAdminNotice(`截图已上传，压缩到 ${(uploaded.sizeBytes / 1024).toFixed(1)}KB。`);
    } catch (error) {
      setAdminNotice(error instanceof Error ? error.message : '上传截图失败');
    } finally {
      setBusyKey(null);
    }
  };

  const adminTabs = [
    { key: 'apps' as const, label: `产品 (${apps.length})` },
    { key: 'patterns' as const, label: `模式 (${patterns.length})` },
    { key: 'discussions' as const, label: `讨论 (${discussions.length})` },
    { key: 'submissions' as const, label: `提交 (${submissions.length})` },
    { key: 'subscribers' as const, label: `订阅者 (${subscribers.length})` },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
      <div className="space-y-3">
        <h1 className="text-4xl font-serif italic">Admin 后台</h1>
        <p className="text-brand-ink/50">当前版本优先满足初期录入和维护：支持核心数据的增删改查，流程和权限下一版再细化。</p>
        {adminNotice ? <div className="rounded-2xl border border-brand-line/10 bg-white px-4 py-3 text-sm text-brand-ink/60">{adminNotice}</div> : null}
      </div>

      <div className="flex flex-wrap gap-2">
        {adminTabs.map((tab) => (
          <button
            key={tab.key}
            type="button"
            onClick={() => setActiveTab(tab.key)}
            className={cn(
              'rounded-full border px-4 py-2 text-sm font-medium transition-colors',
              activeTab === tab.key ? 'border-brand-ink bg-brand-ink text-brand-bg' : 'border-brand-line/10 bg-white text-brand-ink/60 hover:border-brand-ink/30',
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === 'apps' ? (
        <div className="grid grid-cols-1 xl:grid-cols-[420px_minmax(0,1fr)] gap-8">
          <aside className="rounded-3xl border border-brand-line/10 bg-white p-6 shadow-sm space-y-4 h-fit">
            <div className="flex items-center justify-between gap-4">
              <h2 className="text-2xl font-serif italic">产品录入</h2>
              <button type="button" onClick={resetAppDraft} className="text-xs font-bold text-brand-ink/40 hover:text-brand-ink/70">新建</button>
            </div>
            <div className="grid grid-cols-1 gap-3">
              <input value={appDraft.slug} onChange={(e) => setAppDraft((c) => ({ ...c, slug: e.target.value }))} placeholder="slug" className="rounded-2xl bg-brand-ink/5 px-4 py-3 outline-none" />
              <input value={appDraft.name} onChange={(e) => setAppDraft((c) => ({ ...c, name: e.target.value }))} placeholder="产品名称" className="rounded-2xl bg-brand-ink/5 px-4 py-3 outline-none" />
              <input value={appDraft.tagline} onChange={(e) => setAppDraft((c) => ({ ...c, tagline: e.target.value }))} placeholder="一句话描述" className="rounded-2xl bg-brand-ink/5 px-4 py-3 outline-none" />
              <input value={appDraft.saveTimeLabel} onChange={(e) => setAppDraft((c) => ({ ...c, saveTimeLabel: e.target.value }))} placeholder="省下的 30 秒" className="rounded-2xl bg-brand-ink/5 px-4 py-3 outline-none" />
              <div className="grid grid-cols-2 gap-3">
                <input value={appDraft.category} onChange={(e) => setAppDraft((c) => ({ ...c, category: e.target.value }))} placeholder="分类" className="rounded-2xl bg-brand-ink/5 px-4 py-3 outline-none" />
                <select value={appDraft.pricing} onChange={(e) => setAppDraft((c) => ({ ...c, pricing: e.target.value }))} className="rounded-2xl bg-brand-ink/5 px-4 py-3 outline-none">
                  {Object.keys(pricingLabelMap).map((key) => <option key={key} value={key}>{pricingLabelMap[key]}</option>)}
                </select>
              </div>
              <input value={appDraft.targetPersona} onChange={(e) => setAppDraft((c) => ({ ...c, targetPersona: e.target.value }))} placeholder="目标用户" className="rounded-2xl bg-brand-ink/5 px-4 py-3 outline-none" />
              <input value={appDraft.hookAngle} onChange={(e) => setAppDraft((c) => ({ ...c, hookAngle: e.target.value }))} placeholder="亮点钩子" className="rounded-2xl bg-brand-ink/5 px-4 py-3 outline-none" />
              <div className="grid grid-cols-2 gap-3">
                <input value={appDraft.difficulty} onChange={(e) => setAppDraft((c) => ({ ...c, difficulty: e.target.value }))} placeholder="难度" className="rounded-2xl bg-brand-ink/5 px-4 py-3 outline-none" />
                <input value={appDraft.heatScore} onChange={(e) => setAppDraft((c) => ({ ...c, heatScore: e.target.value }))} placeholder="热度" className="rounded-2xl bg-brand-ink/5 px-4 py-3 outline-none" />
              </div>
              <select value={appDraft.patternId} onChange={(e) => setAppDraft((c) => ({ ...c, patternId: e.target.value }))} className="rounded-2xl bg-brand-ink/5 px-4 py-3 outline-none">
                <option value="">未关联模式</option>
                {patterns.map((pattern) => <option key={pattern.id} value={pattern.id}>{pattern.name}</option>)}
              </select>
              <textarea value={appDraft.channelsText} onChange={(e) => setAppDraft((c) => ({ ...c, channelsText: e.target.value }))} rows={3} placeholder="渠道（每行一个）" className="rounded-2xl bg-brand-ink/5 px-4 py-3 outline-none resize-none" />
              <textarea value={appDraft.trustSignalsText} onChange={(e) => setAppDraft((c) => ({ ...c, trustSignalsText: e.target.value }))} rows={3} placeholder="可信标签（每行一个）" className="rounded-2xl bg-brand-ink/5 px-4 py-3 outline-none resize-none" />
              <textarea value={appDraft.screenshotUrlsText} onChange={(e) => setAppDraft((c) => ({ ...c, screenshotUrlsText: e.target.value }))} rows={4} placeholder="截图地址（每行一个）" className="rounded-2xl bg-brand-ink/5 px-4 py-3 outline-none resize-none" />
              <label className="rounded-2xl border border-dashed border-brand-line/20 bg-brand-ink/[0.02] px-4 py-4 cursor-pointer hover:bg-brand-ink/[0.03] transition-colors">
                <input type="file" accept="image/*" className="hidden" onChange={(e) => void uploadAdminScreenshot(e.target.files?.[0])} />
                <div className="text-sm font-semibold text-brand-ink/60">{busyKey === 'upload-app-screenshot' ? '截图上传中...' : '上传截图并加入列表'}</div>
                <div className="mt-1 text-xs text-brand-ink/35">自动压缩并保存到当前服务器。</div>
              </label>
              <textarea value={appDraft.teardownJson} onChange={(e) => setAppDraft((c) => ({ ...c, teardownJson: e.target.value }))} rows={8} placeholder="Teardown JSON（可选）" className="rounded-2xl bg-brand-ink/5 px-4 py-3 font-mono text-xs outline-none resize-none" />
              <textarea value={appDraft.assetBundleJson} onChange={(e) => setAppDraft((c) => ({ ...c, assetBundleJson: e.target.value }))} rows={6} placeholder="Asset Bundle JSON（可选）" className="rounded-2xl bg-brand-ink/5 px-4 py-3 font-mono text-xs outline-none resize-none" />
            </div>
            <div className="flex gap-3">
              <button type="button" onClick={() => void saveApp()} disabled={busyKey === 'save-app'} className="flex-1 rounded-2xl bg-brand-ink px-4 py-3 text-sm font-bold text-brand-bg disabled:opacity-50">{appDraft.id ? '更新产品' : '创建产品'}</button>
              {appDraft.id ? (
                <button type="button" onClick={() => void removeApp(appDraft.id)} disabled={busyKey === `delete-app-${appDraft.id}`} className="rounded-2xl bg-red-50 px-4 py-3 text-sm font-bold text-red-700 disabled:opacity-50">删除</button>
              ) : null}
            </div>
          </aside>
          <section className="rounded-3xl border border-brand-line/10 bg-white p-6 shadow-sm space-y-4">
            <h2 className="text-2xl font-serif italic">现有产品</h2>
            <div className="space-y-3">
              {apps.map((item) => (
                <div key={item.id} className="rounded-2xl border border-brand-line/10 px-4 py-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="space-y-1">
                      <button type="button" onClick={() => selectApp(item)} className="text-left text-base font-semibold hover:text-brand-ink/70">{item.name}</button>
                      <div className="text-xs text-brand-ink/35">{item.slug}</div>
                      <div className="text-xs text-brand-ink/50 line-clamp-2">{item.tagline || '待补充一句话描述'}</div>
                    </div>
                    <button type="button" onClick={() => void removeApp(item.id)} disabled={busyKey === `delete-app-${item.id}`} className="text-xs font-bold text-red-600 disabled:opacity-50">删除</button>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>
      ) : null}

      {activeTab === 'patterns' ? (
        <div className="grid grid-cols-1 xl:grid-cols-[420px_minmax(0,1fr)] gap-8">
          <aside className="rounded-3xl border border-brand-line/10 bg-white p-6 shadow-sm space-y-4 h-fit">
            <div className="flex items-center justify-between gap-4">
              <h2 className="text-2xl font-serif italic">模式录入</h2>
              <button type="button" onClick={resetPatternDraft} className="text-xs font-bold text-brand-ink/40 hover:text-brand-ink/70">新建</button>
            </div>
            <div className="grid grid-cols-1 gap-3">
              <input value={patternDraft.slug} onChange={(e) => setPatternDraft((c) => ({ ...c, slug: e.target.value }))} placeholder="slug" className="rounded-2xl bg-brand-ink/5 px-4 py-3 outline-none" />
              <input value={patternDraft.name} onChange={(e) => setPatternDraft((c) => ({ ...c, name: e.target.value }))} placeholder="模式名称" className="rounded-2xl bg-brand-ink/5 px-4 py-3 outline-none" />
              <textarea value={patternDraft.description} onChange={(e) => setPatternDraft((c) => ({ ...c, description: e.target.value }))} rows={4} placeholder="模式描述" className="rounded-2xl bg-brand-ink/5 px-4 py-3 outline-none resize-none" />
              <textarea value={patternDraft.useCasesText} onChange={(e) => setPatternDraft((c) => ({ ...c, useCasesText: e.target.value }))} rows={5} placeholder="适用场景（每行一个）" className="rounded-2xl bg-brand-ink/5 px-4 py-3 outline-none resize-none" />
            </div>
            <div className="flex gap-3">
              <button type="button" onClick={() => void savePattern()} disabled={busyKey === 'save-pattern'} className="flex-1 rounded-2xl bg-brand-ink px-4 py-3 text-sm font-bold text-brand-bg disabled:opacity-50">{patternDraft.id ? '更新模式' : '创建模式'}</button>
              {patternDraft.id ? (
                <button type="button" onClick={() => void removePattern(patternDraft.id)} disabled={busyKey === `delete-pattern-${patternDraft.id}`} className="rounded-2xl bg-red-50 px-4 py-3 text-sm font-bold text-red-700 disabled:opacity-50">删除</button>
              ) : null}
            </div>
          </aside>
          <section className="rounded-3xl border border-brand-line/10 bg-white p-6 shadow-sm space-y-4">
            <h2 className="text-2xl font-serif italic">现有模式</h2>
            <div className="space-y-3">
              {patterns.map((item) => (
                <div key={item.id} className="rounded-2xl border border-brand-line/10 px-4 py-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="space-y-1">
                      <button type="button" onClick={() => selectPattern(item)} className="text-left text-base font-semibold hover:text-brand-ink/70">{item.name}</button>
                      <div className="text-xs text-brand-ink/35">{item.slug}</div>
                      <div className="text-xs text-brand-ink/50">{item.apps.length} 个关联产品</div>
                    </div>
                    <button type="button" onClick={() => void removePattern(item.id)} disabled={busyKey === `delete-pattern-${item.id}`} className="text-xs font-bold text-red-600 disabled:opacity-50">删除</button>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>
      ) : null}

      {activeTab === 'discussions' ? (
        <section className="rounded-3xl border border-brand-line/10 bg-white p-6 shadow-sm space-y-4">
          <h2 className="text-2xl font-serif italic">讨论维护</h2>
          <div className="space-y-3">
            {discussions.map((item) => (
              <div key={item.id} className="rounded-2xl border border-brand-line/10 px-4 py-4 space-y-3">
                <input
                  defaultValue={item.title}
                  onBlur={(e) => {
                    if (e.target.value.trim() && e.target.value !== item.title) {
                      void saveDiscussionTitle(item.id, e.target.value);
                    }
                  }}
                  className="w-full rounded-xl bg-brand-ink/5 px-3 py-2 text-sm outline-none"
                />
                <div className="flex items-center justify-between gap-4 text-xs text-brand-ink/40">
                  <span>{item.comments.length} 条评论 • {item.likesCount} 赞</span>
                  <button type="button" onClick={() => void removeDiscussion(item.id)} disabled={busyKey === `delete-discussion-${item.id}`} className="font-bold text-red-600 disabled:opacity-50">删除讨论</button>
                </div>
              </div>
            ))}
          </div>
        </section>
      ) : null}

      {activeTab === 'submissions' ? (
        <section className="rounded-3xl border border-brand-line/10 bg-white p-6 shadow-sm space-y-4">
          <h2 className="text-2xl font-serif italic">提交维护</h2>
          <div className="space-y-3">
            {submissions.map((item) => (
              <div key={item.id} className="rounded-2xl border border-brand-line/10 px-4 py-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-1">
                    <div className="font-semibold">{item.productName}</div>
                    <div className="text-xs text-brand-ink/35">{item.websiteUrl}</div>
                    <div className="text-xs text-brand-ink/45">状态：{item.status}</div>
                  </div>
                  <div className="flex gap-2">
                    <button type="button" onClick={() => void moderateSubmission(item.id, 'APPROVED')} disabled={busyKey === `review-${item.id}`} className="rounded-xl bg-emerald-50 px-3 py-2 text-xs font-bold text-emerald-700 disabled:opacity-50">通过</button>
                    <button type="button" onClick={() => void moderateSubmission(item.id, 'REJECTED')} disabled={busyKey === `review-${item.id}`} className="rounded-xl bg-amber-50 px-3 py-2 text-xs font-bold text-amber-700 disabled:opacity-50">拒绝</button>
                    <button type="button" onClick={() => void removeSubmission(item.id)} disabled={busyKey === `delete-submission-${item.id}`} className="rounded-xl bg-red-50 px-3 py-2 text-xs font-bold text-red-700 disabled:opacity-50">删除</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      ) : null}

      {activeTab === 'subscribers' ? (
        <div className="grid grid-cols-1 xl:grid-cols-[420px_minmax(0,1fr)] gap-8">
          <aside className="rounded-3xl border border-brand-line/10 bg-white p-6 shadow-sm space-y-4 h-fit">
            <div className="flex items-center justify-between gap-4">
              <h2 className="text-2xl font-serif italic">订阅者维护</h2>
              <button type="button" onClick={resetSubscriberDraft} className="text-xs font-bold text-brand-ink/40 hover:text-brand-ink/70">新建</button>
            </div>
            <input value={subscriberDraft.email} onChange={(e) => setSubscriberDraft((c) => ({ ...c, email: e.target.value }))} placeholder="email@example.com" className="w-full rounded-2xl bg-brand-ink/5 px-4 py-3 outline-none" />
            <div className="flex gap-3">
              <button type="button" onClick={() => void saveSubscriber()} disabled={busyKey === 'save-subscriber'} className="flex-1 rounded-2xl bg-brand-ink px-4 py-3 text-sm font-bold text-brand-bg disabled:opacity-50">{subscriberDraft.id ? '更新订阅者' : '创建订阅者'}</button>
              {subscriberDraft.id ? (
                <button type="button" onClick={() => void removeSubscriber(subscriberDraft.id)} disabled={busyKey === `delete-subscriber-${subscriberDraft.id}`} className="rounded-2xl bg-red-50 px-4 py-3 text-sm font-bold text-red-700 disabled:opacity-50">删除</button>
              ) : null}
            </div>
          </aside>
          <section className="rounded-3xl border border-brand-line/10 bg-white p-6 shadow-sm space-y-4">
            <h2 className="text-2xl font-serif italic">订阅者列表</h2>
            <div className="space-y-3">
              {subscribers.map((item) => (
                <div key={item.id} className="rounded-2xl border border-brand-line/10 px-4 py-4 flex items-center justify-between gap-4">
                  <button type="button" onClick={() => setSubscriberDraft({ id: item.id, email: item.email })} className="text-left text-sm hover:text-brand-ink/70">{item.email}</button>
                  <button type="button" onClick={() => void removeSubscriber(item.id)} disabled={busyKey === `delete-subscriber-${item.id}`} className="text-xs font-bold text-red-600 disabled:opacity-50">删除</button>
                </div>
              ))}
            </div>
          </section>
        </div>
      ) : null}
    </div>
  );
};

export default function App() {
  return (
    <Router>
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/directory" element={<DirectoryPage />} />
            <Route path="/patterns" element={<PatternsPage />} />
            <Route path="/patterns/:slug" element={<PatternDetailPage />} />
            <Route path="/intelligence/:slug" element={<IntelligencePage />} />
            <Route path="/discussions" element={<DiscussionsPage />} />
            <Route path="/discussions/:id" element={<DiscussionDetailPage />} />
            <Route path="/submit" element={<SubmitPage />} />
            <Route path="/admin" element={<AdminPage />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}
