import { PricingModel, PrismaClient, TargetType } from '@prisma/client';

const prisma = new PrismaClient();

const patternSeeds = [
  {
    slug: 'podcast-clipping',
    name: '播客内容再利用',
    description: '把长播客快速切成短视频、图文卡片和社媒摘要，服务创作者与品牌增长团队。',
    useCases: ['内容增长', '创作者工具', '短视频分发'],
  },
  {
    slug: 'meeting-memory',
    name: '会议记忆助手',
    description: '围绕会议记录、待办提取、知识沉淀构建的高频办公工作流。',
    useCases: ['办公效率', '知识管理', '团队协作'],
  },
  {
    slug: 'ugc-commerce',
    name: '电商 UGC 工厂',
    description: '面向电商商家生成素材脚本、口播文案与投放变体，缩短内容生产周期。',
    useCases: ['电商增长', '广告投放', '素材生成'],
  },
  {
    slug: 'lead-research',
    name: '销售线索研究',
    description: '抓取目标公司与联系人公开信息，自动生成外联前的研究摘要。',
    useCases: ['销售外联', 'B2B SaaS', '客户研究'],
  },
  {
    slug: 'seo-refresh',
    name: '老内容 SEO 翻新',
    description: '识别自然流量下滑页面，自动给出重写建议与结构升级方案。',
    useCases: ['SEO', '内容运营', '站点增长'],
  },
  {
    slug: 'cross-border-catalog',
    name: '跨境选品目录',
    description: '聚合平台热销信号、竞品定价与评论洞察，帮助卖家更快筛选新品。',
    useCases: ['跨境电商', '选品研究', '市场情报'],
  },
  {
    slug: 'notion-os',
    name: '模板化团队 OS',
    description: '把项目管理、知识库、CRM 等流程封装成可复制模板，降低搭建门槛。',
    useCases: ['团队管理', '模板市场', 'SaaS 增长'],
  },
  {
    slug: 'creator-inbox',
    name: '创作者合作收件箱',
    description: '集中管理品牌邀约、报价、素材回传和合作排期。',
    useCases: ['创作者经济', '商务管理', '协作平台'],
  },
  {
    slug: 'community-radar',
    name: '社区情报雷达',
    description: '持续追踪 Reddit、X、Product Hunt 等社区话题，提炼用户痛点与新需求。',
    useCases: ['用户研究', '产品发现', '舆情洞察'],
  },
  {
    slug: 'ai-landing-ops',
    name: 'AI 落地页快反',
    description: '围绕单页转化测试、文案变体与 CTA 实验形成快速上线体系。',
    useCases: ['落地页优化', '增长实验', '独立站'],
  },
];

type AppSeed = {
  slug: string;
  name: string;
  tagline: string;
  saveTimeLabel: string;
  category: string;
  pricing: PricingModel;
  channels: string[];
  targetPersona: string;
  hookAngle: string;
  trustSignals: string[];
  difficulty: number;
  heatScore: number;
  patternSlug: string;
  screenshotUrls: string[];
  teardown: {
    painSummary: string;
    painScore: string;
    triggerScene: string;
    corePromise: string;
    coreLoop: string;
    keyConstraints: string[];
    mvpScope: string;
    dataInput: string;
    dataOutput: string;
    faultTolerance: string;
    coldStartStrategy: string;
    pricingLogic: string;
    competitorDelta: string;
    riskNotes: string;
    expansionSteps: string[];
    reverseIdeas: string[];
  };
  assets: {
    hasAgentsTemplate: boolean;
    hasSpecTemplate: boolean;
    hasPromptPack: boolean;
    agentsTemplate?: string;
    specTemplate?: string;
    promptPack?: string;
  };
};

const appSeeds: AppSeed[] = [
  {
    slug: 'podclip-studio',
    name: '播客切片工坊',
    tagline: '把 60 分钟播客拆成 20 条可发内容。',
    saveTimeLabel: '替内容团队省下找高光片段和写分发文案的 30 秒。',
    category: '内容',
    pricing: PricingModel.FREEMIUM,
    channels: ['SEO', '小红书', '播客社群'],
    targetPersona: '播客主理人、内容运营、个人 IP 团队',
    hookAngle: '把“播客后期”换壳成“一键分发资产工厂”，而不是剪辑工具。',
    trustSignals: ['可在线体验', '有用户故事'],
    difficulty: 2,
    heatScore: 95,
    patternSlug: 'podcast-clipping',
    screenshotUrls: ['https://images.unsplash.com/photo-1478737270239-2f02b77fc618'],
    teardown: {
      painSummary: '内容团队能录完播客，却很难把长音频高效拆成可传播的短内容。',
      painScore: '高频 / 高痛 / 中高付费',
      triggerScene: '主播在晚上 11:47 录完节目，希望当天就能发出第一波切片。',
      corePromise: '上传音频后，10 分钟内产出多平台可直接发布的内容资产。',
      coreLoop: '录制完成 -> 上传音频 -> 生成高光片段与文案 -> 发布并看反馈 -> 下次继续导入。',
      keyConstraints: ['一键导出', '无需复杂剪辑经验', '字幕可校正'],
      mvpScope: '上传音频、自动找高光、生成字幕、导出标题与封面文案。',
      dataInput: '播客音频、节目标题、可选关键词偏好。',
      dataOutput: '高光片段时间轴、字幕、标题、社媒摘要。',
      faultTolerance: '高光识别不准时允许人工二次勾选并重新生成。',
      coldStartStrategy: '先做 20 个播客主理人案例，靠社群口碑和前后对比图扩散。',
      pricingLogic: '免费试用 3 次，随后按导出分钟数和协作席位订阅收费。',
      competitorDelta: '不是通用剪辑工具，而是围绕播客分发结果组织工作流。',
      riskNotes: '音频识别成本、版权归属与长内容转短内容的合规边界。',
      expansionSteps: ['从单人创作者版到工作室版', '加入平台发布闭环', '扩展到视频访谈与直播回放'],
      reverseIdeas: ['课程切片工坊', '直播回放切片工坊', '采访稿切片工坊', '会议摘要切片工坊', '销售录音切片工坊'],
    },
    assets: {
      hasAgentsTemplate: true,
      hasSpecTemplate: true,
      hasPromptPack: true,
      agentsTemplate: '# 播客切片工坊 AGENTS\n聚焦音频上传、切片、字幕校正与分发。',
      specTemplate: '# 播客切片工坊 SPEC\n包含音频任务、切片结果、导出状态和失败回滚。',
      promptPack: '高光识别、标题生成、封面文案、渠道适配四类 prompt 模板。',
    },
  },
  {
    slug: 'memoflow',
    name: '会后纪要官',
    tagline: '会议结束后自动生成纪要、待办和责任人。',
    saveTimeLabel: '替项目经理省下会后整理纪要和追认待办的 30 秒。',
    category: '效率',
    pricing: PricingModel.PAID,
    channels: ['飞书社群', '微信私域', '口碑转介绍'],
    targetPersona: '中小团队负责人、项目经理、客户成功',
    hookAngle: '把“会议记录”换壳成“任务流转入口”，直接嵌入团队协作。',
    trustSignals: ['可在线体验', '有收入截图'],
    difficulty: 2,
    heatScore: 92,
    patternSlug: 'meeting-memory',
    screenshotUrls: ['https://images.unsplash.com/photo-1454165804606-c3d57bc86b40'],
    teardown: {
      painSummary: '大家愿意开会，但没人愿意承担会后整理与追踪的脏活。',
      painScore: '高频 / 高痛 / 高付费',
      triggerScene: '周会刚结束，负责人要在 5 分钟内同步清晰纪要和 owner。',
      corePromise: '自动提炼纪要、待办与责任人，并推送到协作工具。',
      coreLoop: '会议结束 -> 导入录音 -> 生成纪要与待办 -> 分派负责人 -> 下次会议继续引用历史记录。',
      keyConstraints: ['权限隔离', '支持中文口语', '可追溯原句'],
      mvpScope: '录音转写、行动项提取、责任人分配、飞书同步。',
      dataInput: '会议音频、参会人名单、项目上下文。',
      dataOutput: '纪要摘要、待办列表、负责人和截止时间。',
      faultTolerance: '识别错人名时可手动映射，错漏行动项允许补录。',
      coldStartStrategy: '从咨询团队和客户成功团队切入，用“会后 5 分钟交付纪要”做试用承诺。',
      pricingLogic: '按团队席位收费，企业版按集成数量增购。',
      competitorDelta: '不只是转写，而是把会议变成项目推进节点。',
      riskNotes: '录音隐私、权限合规、跨组织分享时的数据泄露风险。',
      expansionSteps: ['从纪要到任务同步', '从任务同步到项目周报', '从周报到团队知识库'],
      reverseIdeas: ['面试纪要官', '销售复盘官', '客服复盘官', '复诊纪要官', '家教反馈官'],
    },
    assets: {
      hasAgentsTemplate: true,
      hasSpecTemplate: true,
      hasPromptPack: false,
      agentsTemplate: '# 会后纪要官 AGENTS\n聚焦转写、待办提取、权限与同步。',
      specTemplate: '# 会后纪要官 SPEC\n包含会议记录、行动项、权限模型、外部集成。',
    },
  },
  {
    slug: 'adscript-lab',
    name: '爆款口播实验室',
    tagline: '为电商商品快速生成 UGC 口播脚本和镜头提示。',
    saveTimeLabel: '替素材团队省下首轮脚本脑暴和镜头拆分的 30 秒。',
    category: '商业',
    pricing: PricingModel.USAGE_BASED,
    channels: ['抖音', '电商代运营', '广告代理'],
    targetPersona: '电商运营、素材团队、投手',
    hookAngle: '不是“写文案”，而是直接把商品卖点翻译成可拍摄脚本。',
    trustSignals: ['有用户故事'],
    difficulty: 3,
    heatScore: 90,
    patternSlug: 'ugc-commerce',
    screenshotUrls: ['https://images.unsplash.com/photo-1520607162513-77705c0f0d4a'],
    teardown: {
      painSummary: '投放团队要快速测素材，但脚本与镜头分镜总是重复从零开始。',
      painScore: '高频 / 中高痛 / 高付费',
      triggerScene: '新品上架前一天，需要批量产出十几版可拍脚本。',
      corePromise: '输入商品卖点后，直接给到可拍摄脚本、镜头清单与口播话术。',
      coreLoop: '输入卖点 -> 生成脚本 -> 拍摄投放 -> 回收表现 -> 优化下一轮脚本。',
      keyConstraints: ['短时间产出', '适配平台口径', '可多人协作'],
      mvpScope: '卖点输入、脚本生成、镜头表、标题建议。',
      dataInput: '商品卖点、目标人群、平台、价格区间。',
      dataOutput: '口播脚本、镜头建议、标题、反对点回应。',
      faultTolerance: '脚本不贴品时支持手动选择风格模版并快速重生。',
      coldStartStrategy: '先服务 10 家代运营机构，用“单品多脚本”复购拉增长。',
      pricingLogic: '按生成条数和团队席位收费，热点模板包单独售卖。',
      competitorDelta: '从“文案助手”升级到“素材生产工作台”。',
      riskNotes: '平台违规词、行业合规、低质量重复素材导致的效果回落。',
      expansionSteps: ['脚本生成', '素材表现反馈闭环', '达人素材匹配推荐'],
      reverseIdeas: ['短剧脚本实验室', '直播话术实验室', '课程招商实验室', '线索私信实验室', '招聘口播实验室'],
    },
    assets: {
      hasAgentsTemplate: true,
      hasSpecTemplate: true,
      hasPromptPack: true,
      agentsTemplate: '# 爆款口播实验室 AGENTS\n围绕商品输入、脚本生成、审核与导出。',
      specTemplate: '# 爆款口播实验室 SPEC\n定义商品、脚本版本、镜头块和投放反馈。',
      promptPack: '卖点抽取、口播脚本、镜头建议、违规词规避。',
    },
  },
  {
    slug: 'leadmap',
    name: '线索地图',
    tagline: '自动整理目标客户画像，外联前先读一页研究摘要。',
    saveTimeLabel: '替销售省下冷启动前搜公司、搜人和整理切入点的 30 秒。',
    category: '商业',
    pricing: PricingModel.PAID,
    channels: ['LinkedIn', '邮件外联', '销售社区'],
    targetPersona: 'B2B 创始人、销售开发、海外增长团队',
    hookAngle: '把“线索名单”换壳成“外联前研究面板”。',
    trustSignals: ['可在线体验'],
    difficulty: 3,
    heatScore: 86,
    patternSlug: 'lead-research',
    screenshotUrls: ['https://images.unsplash.com/photo-1552664730-d307ca884978'],
    teardown: {
      painSummary: '冷邮件和外联前研究太耗时，导致销售不愿做足准备。',
      painScore: '高频 / 中痛 / 高付费',
      triggerScene: '拿到一批新名单后，希望半小时内筛出值得优先联系的账户。',
      corePromise: '用一页研究摘要替代繁琐的搜集与整理。',
      coreLoop: '导入名单 -> 生成研究摘要 -> 发起外联 -> 记录反馈 -> 优化下一批名单。',
      keyConstraints: ['数据来源稳定', '摘要可信', '支持手动修正'],
      mvpScope: '公司摘要、联系人线索、最近动态、外联切入角度。',
      dataInput: '公司域名、公开资料、联系人信息。',
      dataOutput: '研究摘要、优先级、外联备注。',
      faultTolerance: '抓取不到信息时回退到手动录入与公共模板。',
      coldStartStrategy: '从小型销售团队试点，用“每天多触达 10 个更准客户”切入。',
      pricingLogic: '按团队和月度名单额度收费。',
      competitorDelta: '不是数据库，而是外联前的最后一步研究层。',
      riskNotes: '公开数据准确性、地区合规差异、误导性摘要。',
      expansionSteps: ['研究摘要', '外联协作', 'CRM 反馈闭环'],
      reverseIdeas: ['招聘候选人地图', '媒体联系地图', '投资人地图', '渠道伙伴地图', 'KOL 地图'],
    },
    assets: {
      hasAgentsTemplate: true,
      hasSpecTemplate: true,
      hasPromptPack: false,
      agentsTemplate: '# 线索地图 AGENTS\n聚焦名单导入、资料抓取、摘要生成。',
      specTemplate: '# 线索地图 SPEC\n包含账户、联系人、研究摘要与外联状态。',
    },
  },
  {
    slug: 'refreshseo',
    name: '旧文翻新台',
    tagline: '找到流量下滑页面，给出能执行的更新清单。',
    saveTimeLabel: '替内容团队省下找下滑页面和判断先改哪一篇的 30 秒。',
    category: '内容',
    pricing: PricingModel.FREEMIUM,
    channels: ['SEO 社群', '独立站圈子', '内容营销'],
    targetPersona: 'SEO 负责人、内容团队、独立站运营',
    hookAngle: '不是“写新内容”，而是把旧内容翻新变成周期性增长动作。',
    trustSignals: ['可在线体验', '开源'],
    difficulty: 2,
    heatScore: 84,
    patternSlug: 'seo-refresh',
    screenshotUrls: ['https://images.unsplash.com/photo-1460925895917-afdab827c52f'],
    teardown: {
      painSummary: '旧文章流量掉了，却没人知道该优先修哪篇、怎么修。',
      painScore: '高频 / 中痛 / 中高付费',
      triggerScene: '月度流量复盘时，运营需要快速锁定需要翻新的旧内容。',
      corePromise: '自动找出低效旧文，并输出结构化更新清单。',
      coreLoop: '扫描站点 -> 标记下滑页 -> 输出建议 -> 更新发布 -> 观察恢复效果。',
      keyConstraints: ['读懂搜索意图', '建议要可执行', '低门槛上手'],
      mvpScope: '站点扫描、优先级排序、标题建议、章节缺口提示。',
      dataInput: '页面 URL、基础流量数据、关键词与竞品页面。',
      dataOutput: '更新优先级、改写建议、缺失章节清单。',
      faultTolerance: '建议不准时可切换到保守模式，只给结构和标题层建议。',
      coldStartStrategy: '从 SEO 顾问与独立站群体切入，用案例前后对比拉新。',
      pricingLogic: '免费版限制页数，付费版按站点规模收费。',
      competitorDelta: '不做大而全内容平台，只做旧内容翻新的提效工具。',
      riskNotes: '第三方数据依赖、建议同质化、搜索引擎波动。',
      expansionSteps: ['翻新建议', '自动改写草稿', '跨站内容策略中枢'],
      reverseIdeas: ['旧课翻新台', '旧广告翻新台', '旧海报翻新台', '旧文案翻新台', '旧 FAQ 翻新台'],
    },
    assets: {
      hasAgentsTemplate: true,
      hasSpecTemplate: true,
      hasPromptPack: true,
      agentsTemplate: '# 旧文翻新台 AGENTS\n围绕页面扫描、优先级排序、改写建议。',
      specTemplate: '# 旧文翻新台 SPEC\n包含站点、页面、流量信号与建议版本。',
      promptPack: '搜索意图比对、标题优化、段落补全、FAQ 扩展。',
    },
  },
];

const discussionSeeds = [
  {
    appSlug: 'podclip-studio',
    title: '播客切片工坊值不值得做成团队协作版？',
    likesCount: 12,
    comments: [
      { authorName: '阿北', content: '单人创作者够用，但工作室场景下确实需要审稿和批量导出。' },
      { authorName: 'Mia', content: '如果能直接同步到视频号和小红书草稿箱，续费意愿会更强。' },
    ],
  },
  {
    appSlug: 'memoflow',
    title: '会后纪要官的护城河会不会只是模型提示词？',
    likesCount: 9,
    comments: [
      { authorName: '老纪', content: '真正的价值在于接入企业流程，而不是纯文字总结。' },
      { authorName: 'Rex', content: '如果能对接飞书任务和企业微信审批，壁垒会明显提升。' },
    ],
  },
  {
    appSlug: 'refreshseo',
    title: '旧文翻新类产品怎么证明 ROI？',
    likesCount: 7,
    comments: [
      { authorName: 'Nora', content: '最好展示翻新前后的流量和转化变化，用户会更信服。' },
      { authorName: 'Zane', content: '如果能把优先级排序做准，本身就值回票价。' },
    ],
  },
];

async function main() {
  await prisma.comment.deleteMany();
  await prisma.discussion.deleteMany();
  await prisma.appAssetBundle.deleteMany();
  await prisma.teardown.deleteMany();
  await prisma.app.deleteMany();
  await prisma.pattern.deleteMany();
  await prisma.submission.deleteMany();
  await prisma.subscriber.deleteMany();
  await prisma.digestIssue.deleteMany();

  const patternMap = new Map<string, string>();

  for (const pattern of patternSeeds) {
    const created = await prisma.pattern.create({ data: pattern });
    patternMap.set(pattern.slug, created.id);
  }

  const appMap = new Map<string, string>();

  for (const app of appSeeds) {
    const created = await prisma.app.create({
      data: {
        slug: app.slug,
        name: app.name,
        tagline: app.tagline,
        saveTimeLabel: app.saveTimeLabel,
        category: app.category,
        pricing: app.pricing,
        channels: app.channels,
        targetPersona: app.targetPersona,
        hookAngle: app.hookAngle,
        trustSignals: app.trustSignals,
        difficulty: app.difficulty,
        heatScore: app.heatScore,
        screenshotUrls: app.screenshotUrls,
        patternId: patternMap.get(app.patternSlug),
        teardown: { create: app.teardown },
        assetBundle: { create: app.assets },
      },
    });

    appMap.set(app.slug, created.id);
  }

  for (const discussion of discussionSeeds) {
    const created = await prisma.discussion.create({
      data: {
        title: discussion.title,
        targetType: TargetType.APP,
        targetId: appMap.get(discussion.appSlug)!,
        appId: appMap.get(discussion.appSlug)!,
        likesCount: discussion.likesCount,
      },
    });

    for (const comment of discussion.comments) {
      await prisma.comment.create({
        data: {
          discussionId: created.id,
          authorName: comment.authorName,
          content: comment.content,
        },
      });
    }
  }

  await prisma.submission.createMany({
    data: [
      {
        productName: '短剧封面快做器',
        websiteUrl: 'https://example.com/drama-cover',
        contactEmail: 'creator@example.com',
        selectedPattern: 'ai-landing-ops',
        notes: '主打短剧团队批量做封面和标题。',
      },
      {
        productName: '跨境评价翻译助手',
        websiteUrl: 'https://example.com/review-translator',
        contactEmail: 'seller@example.com',
        selectedPattern: 'cross-border-catalog',
        notes: '想先做评论聚类和退货原因分析。',
      },
    ],
  });

  await prisma.subscriber.createMany({
    data: [{ email: 'ops@hellovibecoding.com' }, { email: 'digest-reader@example.com' }],
  });

  await prisma.digestIssue.create({
    data: {
      issueDate: new Date('2026-03-03T09:00:00.000Z'),
      title: '本周产品观察 #01',
      contentMarkdown: [
        '1. 播客切片工坊：内容再利用赛道仍有增长空间。',
        '2. 会后纪要官：团队协作场景决定续费率。',
        '3. 旧文翻新台：旧内容运营会成为更明确的效率工具。',
      ].join('\n'),
    },
  });
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (error) => {
    console.error(error);
    await prisma.$disconnect();
    process.exit(1);
  });
