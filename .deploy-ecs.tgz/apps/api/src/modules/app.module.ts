import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ScheduleModule } from '@nestjs/schedule';
import { AdminModule } from './admin/admin.module';
import { AppsModule } from './apps/apps.module';
import { DigestModule } from './digest/digest.module';
import { DiscussionsModule } from './discussions/discussions.module';
import { HealthModule } from './health/health.module';
import { PatternsModule } from './patterns/patterns.module';
import { PrismaModule } from './prisma/prisma.module';
import { SubmissionsModule } from './submissions/submissions.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    ScheduleModule.forRoot(),
    PrismaModule,
    HealthModule,
    AppsModule,
    PatternsModule,
    DiscussionsModule,
    SubmissionsModule,
    AdminModule,
    DigestModule,
  ],
})
export class AppModule {}
