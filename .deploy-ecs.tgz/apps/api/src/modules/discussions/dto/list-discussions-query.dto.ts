export interface ListDiscussionsQueryDto {
  targetType?: 'APP' | 'PATTERN';
  targetId?: string;
  sort?: 'latest' | 'top';
  page?: string;
  pageSize?: string;
}
