export interface CreateDiscussionDto {
  title: string;
  targetType: 'APP' | 'PATTERN';
  targetId: string;
  authorName: string;
  content: string;
}
