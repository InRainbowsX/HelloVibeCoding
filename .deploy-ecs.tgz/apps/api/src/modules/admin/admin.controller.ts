import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UploadedFile, UseInterceptors } from '@nestjs/common';
import { ApiOkResponse, ApiTags } from '@nestjs/swagger';
import { FileInterceptor } from '@nestjs/platform-express';
import { AdminService } from './admin.service';
import { ReviewSubmissionDto } from './dto/review-submission.dto';

@ApiTags('admin')
@Controller('admin')
export class AdminController {
  constructor(private readonly adminService: AdminService) {}

  @Get('submissions')
  @ApiOkResponse({ description: 'List submissions for moderation.' })
  listSubmissions(@Query('status') status?: string) {
    return this.adminService.listSubmissions(status);
  }

  @Post('submissions/:id/review')
  @ApiOkResponse({ description: 'Review and optionally publish a submission.' })
  reviewSubmission(@Param('id') id: string, @Body() dto: ReviewSubmissionDto) {
    return this.adminService.reviewSubmission(id, dto);
  }

  @Delete('submissions/:id')
  @ApiOkResponse({ description: 'Delete a submission.' })
  deleteSubmission(@Param('id') id: string) {
    return this.adminService.deleteSubmission(id);
  }

  @Get('apps')
  @ApiOkResponse({ description: 'List apps for admin CRUD.' })
  listApps() {
    return this.adminService.listApps();
  }

  @Post('apps')
  @ApiOkResponse({ description: 'Create an app draft with nested teardown and asset bundle.' })
  createApp(@Body() payload: Record<string, unknown>) {
    return this.adminService.createApp(payload);
  }

  @Patch('apps/:id')
  @ApiOkResponse({ description: 'Update an app draft with nested teardown and asset bundle.' })
  updateApp(@Param('id') id: string, @Body() payload: Record<string, unknown>) {
    return this.adminService.updateApp(id, payload);
  }

  @Delete('apps/:id')
  @ApiOkResponse({ description: 'Delete an app draft.' })
  deleteApp(@Param('id') id: string) {
    return this.adminService.deleteApp(id);
  }

  @Get('patterns')
  @ApiOkResponse({ description: 'List patterns for admin CRUD.' })
  listPatterns() {
    return this.adminService.listPatterns();
  }

  @Post('patterns')
  @ApiOkResponse({ description: 'Create a pattern.' })
  createPattern(@Body() payload: Record<string, unknown>) {
    return this.adminService.createPattern(payload);
  }

  @Patch('patterns/:id')
  @ApiOkResponse({ description: 'Update a pattern.' })
  updatePattern(@Param('id') id: string, @Body() payload: Record<string, unknown>) {
    return this.adminService.updatePattern(id, payload);
  }

  @Delete('patterns/:id')
  @ApiOkResponse({ description: 'Delete a pattern.' })
  deletePattern(@Param('id') id: string) {
    return this.adminService.deletePattern(id);
  }

  @Get('discussions')
  @ApiOkResponse({ description: 'List discussions for admin CRUD.' })
  listDiscussions() {
    return this.adminService.listDiscussions();
  }

  @Patch('discussions/:id')
  @ApiOkResponse({ description: 'Update a discussion title.' })
  updateDiscussion(@Param('id') id: string, @Body() payload: Record<string, unknown>) {
    return this.adminService.updateDiscussion(id, payload);
  }

  @Delete('discussions/:id')
  @ApiOkResponse({ description: 'Delete a discussion thread and comments.' })
  deleteDiscussion(@Param('id') id: string) {
    return this.adminService.deleteDiscussion(id);
  }

  @Get('subscribers')
  @ApiOkResponse({ description: 'List subscribers for admin CRUD.' })
  listSubscribers() {
    return this.adminService.listSubscribers();
  }

  @Post('subscribers')
  @ApiOkResponse({ description: 'Create a subscriber.' })
  createSubscriber(@Body() payload: Record<string, unknown>) {
    return this.adminService.createSubscriber(payload);
  }

  @Patch('subscribers/:id')
  @ApiOkResponse({ description: 'Update a subscriber email.' })
  updateSubscriber(@Param('id') id: string, @Body() payload: Record<string, unknown>) {
    return this.adminService.updateSubscriber(id, payload);
  }

  @Delete('subscribers/:id')
  @ApiOkResponse({ description: 'Delete a subscriber.' })
  deleteSubscriber(@Param('id') id: string) {
    return this.adminService.deleteSubscriber(id);
  }

  @Post('uploads/screenshot')
  @UseInterceptors(FileInterceptor('file'))
  @ApiOkResponse({ description: 'Upload and compress a screenshot to <= 100KB.' })
  uploadScreenshot(@UploadedFile() file: { buffer?: Buffer } | undefined) {
    return this.adminService.uploadScreenshot(file);
  }
}
