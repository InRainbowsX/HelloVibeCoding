# digest module

TODO: implement module controllers/services in SPEC phase.
