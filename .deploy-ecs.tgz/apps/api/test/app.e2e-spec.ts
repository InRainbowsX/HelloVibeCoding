import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request = require('supertest');
import { AppModule } from '../src/modules/app.module';

const databaseUrl = process.env.DATABASE_URL || 'postgresql://postgres:postgres@localhost:5432/hellovibecoding';
const onePixelSvg = Buffer.from(
  '<svg xmlns="http://www.w3.org/2000/svg" width="8" height="8"><rect width="8" height="8" fill="#111111"/></svg>',
);

describe('App e2e', () => {
  let app: INestApplication;

  beforeAll(async () => {
    process.env.DATABASE_URL = databaseUrl;
    const moduleRef = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleRef.createNestApplication();
    app.setGlobalPrefix('api/v1');
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  it('GET /api/v1/apps returns a paginated list', async () => {
    const response = await request(app.getHttpServer()).get('/api/v1/apps?page=1&pageSize=20');

    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.page).toBe(1);
    expect(response.body.pageSize).toBe(20);
    expect(response.body.items.some((item: { name: string; tagline: string | null }) => item.name === '播客切片工坊')).toBe(true);
    expect(response.body.items.some((item: { tagline: string | null }) => Boolean(item.tagline))).toBe(true);
  });

  it('GET /api/v1/patterns returns available patterns', async () => {
    const response = await request(app.getHttpServer()).get('/api/v1/patterns');

    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.total).toBeGreaterThan(0);
  });

  it('GET /api/v1/discussions/:id returns discussion detail', async () => {
    const listResponse = await request(app.getHttpServer()).get('/api/v1/discussions?page=1&pageSize=1');
    expect(listResponse.status).toBe(200);
    expect(listResponse.body.items.length).toBeGreaterThan(0);

    const id = listResponse.body.items[0].id as string;
    const response = await request(app.getHttpServer()).get(`/api/v1/discussions/${id}`);

    expect(response.status).toBe(200);
    expect(response.body.id).toBe(id);
    expect(Array.isArray(response.body.comments)).toBe(true);
  });

  it('POST /api/v1/discussions creates a discussion thread with the opening comment', async () => {
    const appsResponse = await request(app.getHttpServer()).get('/api/v1/apps?page=1&pageSize=1');
    expect(appsResponse.status).toBe(200);
    expect(appsResponse.body.items.length).toBeGreaterThan(0);

    const target = appsResponse.body.items[0] as { id: string };
    const response = await request(app.getHttpServer()).post('/api/v1/discussions').send({
      title: '新建测试讨论话题',
      targetType: 'APP',
      targetId: target.id,
      authorName: '测试用户',
      content: '这是一个用于验证创建讨论接口的首条评论。',
    });

    expect(response.status).toBe(201);
    expect(response.body.title).toBe('新建测试讨论话题');
    expect(response.body.targetType).toBe('APP');
    expect(Array.isArray(response.body.comments)).toBe(true);
    expect(response.body.comments).toHaveLength(1);
    expect(response.body.comments[0].authorName).toBe('测试用户');
  });

  it('POST /api/v1/discussions/:id/like increments the discussion like count', async () => {
    const listResponse = await request(app.getHttpServer()).get('/api/v1/discussions?page=1&pageSize=1');
    expect(listResponse.status).toBe(200);
    expect(listResponse.body.items.length).toBeGreaterThan(0);

    const discussion = listResponse.body.items[0] as { id: string; likesCount: number };
    const response = await request(app.getHttpServer()).post(`/api/v1/discussions/${discussion.id}/like`).send({});

    expect(response.status).toBe(201);
    expect(response.body.id).toBe(discussion.id);
    expect(response.body.likesCount).toBe(discussion.likesCount + 1);
  });

  it('POST /api/v1/discussions/:id/comments creates a flat reply', async () => {
    const listResponse = await request(app.getHttpServer()).get('/api/v1/discussions?page=1&pageSize=1');
    expect(listResponse.status).toBe(200);
    expect(listResponse.body.items.length).toBeGreaterThan(0);

    const discussion = listResponse.body.items[0] as { id: string; comments: Array<{ id: string }> };
    const existingCount = discussion.comments.length;
    const response = await request(app.getHttpServer()).post(`/api/v1/discussions/${discussion.id}/comments`).send({
      authorName: '评论测试用户',
      content: '这是一个用于验证评论创建的回复。',
      replyToCommentId: discussion.comments[0]?.id,
    });

    expect(response.status).toBe(201);
    expect(response.body.authorName).toBe('评论测试用户');
    expect(response.body.discussionId).toBe(discussion.id);

    const detailResponse = await request(app.getHttpServer()).get(`/api/v1/discussions/${discussion.id}`);
    expect(detailResponse.status).toBe(200);
    expect(detailResponse.body.comments).toHaveLength(existingCount + 1);
  });

  it('POST /api/v1/submissions creates a pending submission', async () => {
    const response = await request(app.getHttpServer()).post('/api/v1/submissions').send({
      productName: '测试提交产品',
      websiteUrl: 'https://example.com/test-submission',
      contactEmail: 'submit-test@example.com',
      notes: '用于验证提交流程',
    });

    expect(response.status).toBe(201);
    expect(response.body.productName).toBe('测试提交产品');
    expect(response.body.contactEmail).toBe('submit-test@example.com');
    expect(response.body.status).toBe('PENDING');
  });

  it('POST /api/v1/subscribe upserts a subscriber', async () => {
    const response = await request(app.getHttpServer()).post('/api/v1/subscribe').send({
      email: 'digest-test@example.com',
    });

    expect(response.status).toBe(201);
    expect(response.body.success).toBe(true);
    expect(response.body.subscriber.email).toBe('digest-test@example.com');
  });

  it('POST /api/v1/admin/submissions/:id/review approves a submission and creates an app draft', async () => {
    const patternResponse = await request(app.getHttpServer()).get('/api/v1/patterns');
    expect(patternResponse.status).toBe(200);
    expect(patternResponse.body.items.length).toBeGreaterThan(0);

    const selectedPattern = patternResponse.body.items[0].slug as string;
    const submissionResponse = await request(app.getHttpServer()).post('/api/v1/submissions').send({
      productName: '审核流测试产品',
      websiteUrl: 'https://example.com/review-test',
      contactEmail: 'review-test@example.com',
      selectedPattern,
    });

    expect(submissionResponse.status).toBe(201);

    const reviewResponse = await request(app.getHttpServer())
      .post(`/api/v1/admin/submissions/${submissionResponse.body.id}/review`)
      .send({
        status: 'APPROVED',
        slug: 'review-flow-test-app',
      });

    expect(reviewResponse.status).toBe(201);
    expect(reviewResponse.body.submission.status).toBe('APPROVED');
    expect(reviewResponse.body.createdApp.slug).toBe('review-flow-test-app');
    expect(reviewResponse.body.createdApp.name).toBe('审核流测试产品');
  });

  it('POST /api/v1/admin/uploads/screenshot stores a compressed screenshot on the server', async () => {
    const response = await request(app.getHttpServer())
      .post('/api/v1/admin/uploads/screenshot')
      .attach('file', onePixelSvg, { filename: 'tiny.svg', contentType: 'image/svg+xml' });

    expect(response.status).toBe(201);
    expect(response.body.url).toContain('/uploads/screenshots/');
    expect(response.body.sizeBytes).toBeLessThanOrEqual(100 * 1024);
  });

  it('admin app CRUD creates, updates and deletes an app draft', async () => {
    const createResponse = await request(app.getHttpServer()).post('/api/v1/admin/apps').send({
      slug: 'admin-crud-test-app',
      name: '后台 CRUD 测试产品',
      saveTimeLabel: '替录入人员省下补录数据的 30 秒。',
      category: '效率',
      pricing: 'FREEMIUM',
      channels: ['admin'],
      targetPersona: '运营同学',
      hookAngle: '直接在后台维护真实内容',
      trustSignals: ['可在线体验'],
    });

    expect(createResponse.status).toBe(201);
    expect(createResponse.body.slug).toBe('admin-crud-test-app');

    const updateResponse = await request(app.getHttpServer())
      .patch(`/api/v1/admin/apps/${createResponse.body.id}`)
      .send({
        name: '后台 CRUD 测试产品（已更新）',
        heatScore: 19,
      });

    expect(updateResponse.status).toBe(200);
    expect(updateResponse.body.name).toBe('后台 CRUD 测试产品（已更新）');
    expect(updateResponse.body.heatScore).toBe(19);

    const deleteResponse = await request(app.getHttpServer())
      .delete(`/api/v1/admin/apps/${createResponse.body.id}`);

    expect(deleteResponse.status).toBe(200);
    expect(deleteResponse.body.success).toBe(true);
  });

  it('GET /api/v1/apps/:slug returns work layer, teardown layer and asset layer fields', async () => {
    const response = await request(app.getHttpServer()).get('/api/v1/apps/podclip-studio');

    expect(response.status).toBe(200);
    expect(response.body.name).toBe('播客切片工坊');
    expect(response.body.saveTimeLabel).toContain('30 秒');
    expect(response.body.category).toBe('内容');
    expect(Array.isArray(response.body.trustSignals)).toBe(true);
    expect(response.body.trustSignals).toContain('可在线体验');
    expect(response.body.teardown.mvpScope).toBeTruthy();
    expect(Array.isArray(response.body.teardown.reverseIdeas)).toBe(true);
    expect(response.body.teardown.reverseIdeas.length).toBeGreaterThanOrEqual(5);
    expect(response.body.buildAssets.hasAgentsTemplate).toBe(true);
    expect(response.body.buildAssets.hasSpecTemplate).toBe(true);
    expect(response.body.buildAssets.agentsTemplate).toContain('AGENTS');
    expect(response.body.buildAssets.specTemplate).toContain('SPEC');
  });
});
