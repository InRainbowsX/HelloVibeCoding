#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DOCKER_DIR="$ROOT_DIR/docker"

cd "$ROOT_DIR"

if [[ ! -f "$DOCKER_DIR/.env.ecs" ]]; then
  echo "Missing $DOCKER_DIR/.env.ecs"
  echo "Copy $DOCKER_DIR/.env.ecs.example to $DOCKER_DIR/.env.ecs and update the values first."
  exit 1
fi

mkdir -p "$ROOT_DIR/uploads/screenshots"

echo "Installing dependencies..."
corepack pnpm install

echo "Building web..."
corepack pnpm -C apps/web build

echo "Building api..."
corepack pnpm -C apps/api build

echo "Starting ECS containers..."
docker compose -f "$DOCKER_DIR/docker-compose.ecs.yml" up -d --build

echo "Running Prisma migrate..."
set -a
source "$DOCKER_DIR/.env.ecs"
set +a
corepack pnpm -C apps/api prisma:migrate

echo "Deployment assets are ready."
echo "Check health with: curl http://127.0.0.1/api/v1/health"
