# helloVibeCoding — AGENTS.md（中文）

## Superpowers System
本仓库使用 Codex 按 “AGENTS.md + SPEC + SKILL” 推进。
执行任何任务前，必须加载并遵循以下技能规范：
- $ui-ux-pro-max
- $frontend-design

## 项目一句话
构建 helloVibeCoding：收录已上线产品的“数据库式产品库”，提供商业拆解（8 格）、模式库（Patterns）、讨论社区（扁平评论流）、产品提交与审核、免费 Digest 订阅，为后续推广与扩展预留接口（SEO/广告/收费层）。

## 已确认的关键决策（未经明确指示不得更改）
- 后端：Node.js（NestJS）+ Prisma + PostgreSQL
- 前端：优先复用现有原型（Vite + React），逐步把本地假数据替换为 API
- UI 风格：Notion 风清爽留白、信息密但不拥挤、细分割线、轻 hover；避免强阴影与花哨动效
- 产品库（Apps/Directory）默认 6 列 + 行展开（Row Expand）
- 产品详情（App/Intelligence）先拆解后讨论：首屏结论与三卡 → 截图/亮点 → 8 格拆解 → 同模式家族 → 讨论区
- 讨论（Discussions）为扁平流（非树状），回复用“引用条”表示 replyTo
- 前期不收费：预留广告位（Sponsor Row / Sponsor Card / Digest Sponsor），先跑免费订阅与增长闭环

## 代码仓库推荐结构（可在第 0 阶段落地）
- apps/web：现有 Vite React 原型（保持页面结构：Home/Directory/Intelligence/Patterns/Discussions/Submit）
- apps/api：NestJS 后端
- packages/shared：共享类型/枚举/校验 schema（可选但推荐）
- docker：docker-compose（postgres + redis）
说明：若当前仓库只有前端，新增 apps/api 与 docker；后续可逐步迁移。

## 环境变量约定
- DATABASE_URL=postgresql://<user>:<password>@localhost:5432/hellovibecoding
- REDIS_URL=redis://localhost:6379
- API_BASE_URL=http://localhost:3001（web 调用 api）

## 开发与质量门槛
- TypeScript 全链路；eslint + prettier
- API：Nest Swagger 文档必须可访问
- DB：Prisma migrate 管理 schema
- 所有核心接口必须配最小 e2e/集成测试（至少：apps 列表、app 详情、发评论、提交）
- UI：遵循 $ui-ux-pro-max $frontend-design，列表与详情必须保持留白与信息层级

## 任务执行准则（给 Codex）
1) 先读 SPEC，再动代码；不凭空改需求
2) 每个阶段完成后必须给出：变更清单 + 自测步骤 + 验收要点
3) 任何破坏性重构必须分步骤提交（保持可运行）
4) 优先实现闭环：产品库 → 拆解 → 讨论 → 提交 → 审核 → 发布 → 订阅